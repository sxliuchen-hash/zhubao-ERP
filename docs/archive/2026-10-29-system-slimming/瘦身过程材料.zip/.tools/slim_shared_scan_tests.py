from pathlib import Path
for name in ['BusinessWorkspaces.test.ts','scanTargetGuard.test.ts']:
 f=Path('frontend/src/features/m1/'+name);s=f.read_text(encoding='utf-8').replace("    await wrapper.get('.mobile-order-create').trigger('click');\n",'')
 if name.startswith('Business'):
  s=s.replace("    expect(wrapper.text()).toContain('手机收货');\n",'')
 else:
  a=s.index("  it('岗位报工提交");b=s.index("  it('收货失败",a);part=s[a:b].replace("customerName: '恒信珠宝',", "customerName: '恒信珠宝', quantity: 1, weight: 2.5,")
  part=part.replace("    await wrapper.get('[aria-label=\"完成核对\"]').trigger('click');\n",'').replace("    await wrapper.get('button').element;\n",'')
  part=part.replace("button.text() === '提交雕刻'", "button.text() === '确认雕刻交工'")
  part=part.replace("    vi.mocked(lookupProcessStation).mockResolvedValue(stationView('ZD-100'));", "    vi.mocked(lookupProcessStation).mockResolvedValue(stationView('ZD-100'));\n    vi.mocked(submitProcessStation).mockResolvedValue({ orderCode: 'ZD-100', processName: '雕刻', ledgerCode: 'L-1', movedToSemiFinished: false, stockStatus: 'WIP' });")
  part=part.replace("expect(wrapper.find('[aria-label=\"完成核对\"]').exists()).toBe(true);", "expect(wrapper.find('[aria-label=\"核对 1 内壁刻字\"]').exists()).toBe(true);")
  s=s[:a]+part+s[b:]
  s=s.replace("button.text() === '生成母单'", "button.text() === '确认建单并入库'")
  a=s.index("  it('切到岗位报工会停掉收货摄像头");b=s.index("  it(",a+6);part=s[a:b].replace('切到岗位报工会停掉收货摄像头，迟到条码不能改岗位目标','共享面板暂停时停掉收货摄像头，迟到条码不触发新目标')
  part=part.replace('    const wrapper = mountFieldPanel(ProductionPanel);',"    const suspended = ref(false);\n    const wrapper = mount(IntakePanel, { props: { title: '收货资料', intro: '', field: true }, global: { provide: { 'zhubao-scan-suspended': suspended, 'zhubao-auth-session': ref({ role: 'ADMIN' } as AuthSession) } } });")
  part=part.replace("    await wrapper.get('.mobile-order-back').trigger('click');",'    suspended.value = true; await flushPromises();')
  s=s[:a]+part+s[b:]
 f.write_text(s,encoding='utf-8')
f=Path('frontend/src/features/production/MachineOutputPanel.test.ts');s=f.read_text(encoding='utf-8').replace("suggestedAction: '人工核对'", "suggestedAction: '人工核对', totalRecords: 1, sourceRegisterType: '雕刻', sourceMachineLineNo: '1'").replace("boundRecords: 1 });", "boundRecords: 1, operator: '操机员' });");f.write_text(s,encoding='utf-8')
