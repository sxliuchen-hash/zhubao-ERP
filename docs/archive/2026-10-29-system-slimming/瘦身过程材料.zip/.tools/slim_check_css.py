from pathlib import Path
import csv,re,json
rows=list(csv.DictReader(Path('docs/archive/2026-10-28-deprecation-audit/样式候选.csv').read_text(encoding='utf-8-sig').splitlines()))
classes=sorted({r['类名'] for r in rows if '保留' not in r['初步边界']})
refs={c:[] for c in classes}
for p in Path('frontend/src').rglob('*'):
 if p.suffix not in ['.ts','.vue'] or p.name.endswith('.test.ts'):continue
 text=p.read_text(encoding='utf-8')
 text=re.sub(r'<style\b[^>]*>[\s\S]*?</style>','',text)
 for c in classes:
  if re.search(r'(?<![\w-])'+re.escape(c)+r'(?![\w-])',text):refs[c].append(p.as_posix())
print(json.dumps({'候选类':classes,'现行引用':{c:p for c,p in refs.items() if p}},ensure_ascii=False))
Path('.tools/slim-css-candidates.json').write_text(json.dumps(rows,ensure_ascii=False),encoding='utf-8')
