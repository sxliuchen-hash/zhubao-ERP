from pathlib import Path
f=Path('frontend/src/features/orders/OrderWorkspace.vue');s=f.read_text(encoding='utf-8');s=s.replace("const canCreate = computed(() => openIntake && tabs.value.includes('inbound') && session.value?.effectivePermissions?.includes('BUSINESS_INBOUND_CONFIRM'));", "const canCreate = computed(() => openIntake && tabs.value.some(tab => tab === 'inbound' || tab === 'mobile') && session.value?.effectivePermissions?.includes('BUSINESS_INBOUND_CONFIRM'));\nconst quickActions = computed(() => {\n  const permissions = session.value?.effectivePermissions ?? [];\n  return [\n    { label: '扫码报工', allowed: openProduction && tabs.value.some(tab => ['production', 'progress', 'mobile'].includes(tab)) && permissions.includes('BUSINESS_PRODUCTION_REPORT'), run: () => openProduction?.(null, 'station') },\n    { label: '扫码质检', allowed: openQuality && tabs.value.some(tab => ['quality', 'mobile'].includes(tab)) && ['BUSINESS_QUALITY_FREEZE', 'BUSINESS_REWORK_DISPATCH', 'BUSINESS_REWORK_REPORT', 'BUSINESS_QUALITY_RELEASE'].some(permission => permissions.includes(permission)), run: () => openQuality?.(null) },\n    { label: '扫码发货', allowed: openShipping && tabs.value.some(tab => ['inventory', 'mobile'].includes(tab)) && permissions.includes('BUSINESS_OUTBOUND_SHIPMENT'), run: () => openShipping?.(null) },\n  ].filter(action => action.allowed);\n});")
s=s.replace('<section class="order-list-panel" aria-label="订单查询列表">', '<section class="order-list-panel" aria-label="订单查询列表">\n      <nav v-if="!detailOpen && quickActions.length" class="button-row order-quick-actions" aria-label="本岗办理"><button v-for="action in quickActions" :key="action.label" type="button" class="secondary-button" @click="action.run">{{ action.label }}</button></nav>')
f.write_text(s,encoding='utf-8')
f=Path('frontend/src/App.vue');s=f.read_text(encoding='utf-8').replace("mobile: () => import('./features/m1/MobileOpsWorkspace.vue')",'mobile: orderWorkspaceLoader')
s=s.replace("['inbound', 'production', 'progress', 'quality'].includes(tab)","['inbound', 'production', 'progress', 'quality', 'mobile'].includes(tab)")
s=s.replace("tab === 'inbound' ? 'ORDERS' : 'PRODUCTION'", "tab === 'inbound' || tab === 'mobile' ? 'ORDERS' : 'PRODUCTION'")
s=s.replace("['inbound', 'production', 'progress', 'quality', 'inventory'].includes(tab.key)","['inbound', 'production', 'progress', 'quality', 'inventory', 'mobile'].includes(tab.key)")
f.write_text(s,encoding='utf-8')
f=Path('backend/src/main/java/com/zhubao/erp/business/app/OrderWorkspaceQueryService.java');s=f.read_text(encoding='utf-8').replace('|| menus.contains("quality") || menus.contains("inventory")) {','|| menus.contains("quality") || menus.contains("inventory") || menus.contains("mobile")) {');f.write_text(s,encoding='utf-8')
# 只留共享列表、详情与动作容器，旧手机角色映射和页内表单退出。
for name in ['MobileOpsWorkspace.vue','MobileOrderDetail.vue','MobileOpsWorkspace.test.ts','MobileOrderDetail.test.ts']:
 Path('frontend/src/features/m1/'+name).unlink()
# 原手机工作台的业务验证直接挂载现行共享面板，不再通过已退出的页内动作分发器。
for name in ['BusinessWorkspaces.test.ts','scanTargetGuard.test.ts']:
 f=Path('frontend/src/features/m1/'+name);s=f.read_text(encoding='utf-8').replace("import MobileOpsWorkspace from './MobileOpsWorkspace.vue';", "import IntakePanel from '../intake/IntakePanel.vue';\nimport ProductionPanel from '../production/ProductionPanel.vue';")
 a=s.index('function mountMobileOps()');b=s.index('\nvi.mock(',a)
 s=s[:a]+'''function mountFieldPanel(component: typeof IntakePanel | typeof ProductionPanel) {
  return mount(component, { props: { title: '岗位作业', intro: '', field: true },
    global: { provide: { 'zhubao-auth-session': ref({ role: 'ADMIN' } as AuthSession) } } });
}
'''+s[b:]
 # 按每个原场景的办理类型迁移到对应真实组件。
 pieces=s.split("  it(")
 for i in range(1,len(pieces)):
  part=pieces[i]
  if 'mountMobileOps()' not in part:continue
  panel='ProductionPanel' if "'岗位报工'" in part else 'IntakePanel'
  part=part.replace('mountMobileOps()',f'mountFieldPanel({panel})')
  import re
  part=re.sub(r"    await openMobileAction\(wrapper, '[^']+'\);\n",'',part)
  pieces[i]=part
 s='  it('.join(pieces)
 # 原手机首页的角色按钮断言由共享列表有效权限测试接续。
 if name=='BusinessWorkspaces.test.ts':
  a=s.index("  it('手机现场有质检入口");s=s[:a]+'});\n'
 f.write_text(s,encoding='utf-8')
