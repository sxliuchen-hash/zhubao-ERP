from pathlib import Path

p = Path('backend/src/test/java/com/zhubao/erp/m2/M2ManagementApiSmokeTest.java')
s = p.read_text(encoding='utf-8')
start = s.index('    @Test\n    void exposesBusinessWorkspaceApis()')
end = s.index('    @Test\n    void confirmsInboundThroughBusinessOperationApiAndWritesInventoryLedger()', start)
s = s[:start] + '''    @Test
    void exposesBusinessWorkspaceApis() throws Exception {
        for (String view : List.of("inbound", "production", "quality", "inventory")) {
            ResponseEntity<String> response = signedGet("/api/business/workspaces/" + view, String.class);
            assertThat(response.getStatusCode().is2xxSuccessful()).as(view).isTrue();
            assertThat(json.readTree(response.getBody()).path("data").path("dataSource").asText()).isEqualTo("LIVE");
            assertThat(response.getBody()).doesNotContain("DRAFT-QC-003", "preview-demo", "离线草稿");
        }
        for (String retired : List.of("mobile", "summary")) {
            assertThat(signedGet("/api/business/workspaces/" + retired, String.class).getStatusCode().value()).isEqualTo(404);
        }
    }

    @Test
    void filtersBusinessWorkspaceApisBySessionCustomerScope() throws Exception {
        workspaceDocuments.saveMotherOrder(workspaceMother("MD-WORKSPACE-A", 1001L, "恒信珠宝"));
        workspaceDocuments.saveMotherOrder(workspaceMother("MD-WORKSPACE-B", 1002L, "另一个客户"));
        testAccounts.save(new com.zhubao.erp.security.domain.AuthUserAccount(
                "workspace-scope", testHasher.hash("workspace-scope123"), "范围烟测业务员",
                com.zhubao.erp.security.domain.RoleCode.SALES, com.zhubao.erp.security.domain.DataScope.CUSTOMER_RANGE,
                true, true, List.of("1001")));
        testAccounts.save(new com.zhubao.erp.security.domain.AuthUserAccount(
                "workspace-empty", testHasher.hash("workspace-empty123"), "空范围烟测业务员",
                com.zhubao.erp.security.domain.RoleCode.SALES, com.zhubao.erp.security.domain.DataScope.CUSTOMER_RANGE,
                true, true, List.of()));

        HttpHeaders headers = new HttpHeaders();
        headers.addAll(sessionHeaders("workspace-scope"));
        headers.set("X-Zhubao-Customer-Scope", "1002");
        ResponseEntity<String> response = restTemplate.exchange("/api/business/workspaces/inbound", HttpMethod.GET,
                new HttpEntity<>(headers), String.class);
        assertThat(response.getStatusCode().is2xxSuccessful()).isTrue();
        assertThat(json.readTree(response.getBody()).path("data").path("orders").findValuesAsText("code"))
                .contains("MD-WORKSPACE-A").doesNotContain("MD-WORKSPACE-B");
        ResponseEntity<String> empty = restTemplate.exchange("/api/business/workspaces/inbound", HttpMethod.GET,
                new HttpEntity<>(sessionHeaders("workspace-empty")), String.class);
        assertThat(empty.getStatusCode().is2xxSuccessful()).isTrue();
        assertThat(json.readTree(empty.getBody()).path("data").path("orders").isEmpty()).isTrue();
    }

    private static com.zhubao.erp.business.domain.MotherOrderRecord workspaceMother(String code, Long customerId, String customer) {
        return new com.zhubao.erp.business.domain.MotherOrderRecord(
                code, customerId, customerId, "MAT-18K-RING", "2026-10-29", "", "", "", "收货员", "",
                "烟测货品", "CUSTOMER", true, "RAW", BigDecimal.ONE, "件", BigDecimal.ONE,
                "RAW_WAITING", "", "", null, "", "收货员", "", "", "已入库", "2026-10-29T09:00:00",
                "抛光", "2099-01-01", customer);
    }

''' + s[end:]
p.write_text(s, encoding='utf-8')
