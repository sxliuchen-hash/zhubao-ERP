from pathlib import Path
p=Path('backend/src/test/java/com/zhubao/erp/business/app')
for name in ['ProcessDeliveryTest.java','QualityDeliveryTest.java']:
 f=p/name;s=f.read_text(encoding='utf-8')
 # JDBC 场景必须使用同一数据源的工作单元，内存场景保留内存装配。
 pos=s.index('private static final class JdbcWorld')
 s=s[:pos]+s[pos:].replace('com.zhubao.erp.business.BusinessWorkFixture.unit()', 'com.zhubao.erp.business.BusinessWorkFixture.unit(dataSource)')
 if name.startswith('Process'):
  s=s.replace('oldPath.station().report(sticker("MD-ST-OLD"), "雕刻", carving, "fixture-" + java.util.UUID.randomUUID())','oldPath.station().report(sticker("MD-ST-OLD"), "雕刻", carving)')
  s=s.replace('.hasMessage("交接保存失败");\n        assertThat(world.raw("MD-ST-OLD", 1001L)).isEqualByComparingTo("0");\n        assertThat(world.wip("MD-ST-OLD", 1001L)).isEqualByComparingTo("10");', '.hasMessage("交工必须提供稳定请求编号");\n        assertThat(world.raw("MD-ST-OLD", 1001L)).isEqualByComparingTo("10");\n        assertThat(world.wip("MD-ST-OLD", 1001L)).isEqualByComparingTo("0");')
  s=s.replace('oldPath.station().report(sticker("MD-ST-OLD"), "雕刻", carving))\n                .isInstanceOf(IllegalStateException.class)', 'oldPath.station().report(sticker("MD-ST-OLD"), "雕刻", carving))\n                .isInstanceOf(BusinessException.class)')
 else:
  s=s.replace('oldPath.quality().submit(check("MD-QC-OLD", QualityVerdicts.FAIL, "划伤"), inspector)', 'oldPath.quality().submit(new QualityCheckCommand(sticker("MD-QC-OLD"), "别人", List.of(new QualityCheckLineCommand(1, QualityVerdicts.FAIL, "划伤"))), inspector)')
  s=s.replace('.hasMessage("质检事实保存失败");\n        assertThat(world.semi("MD-QC-OLD", 1001L)).isEqualByComparingTo("0");\n        assertThat(world.frozen("MD-QC-OLD", 1001L)).isEqualByComparingTo("10");\n        assertThat(world.freezes("MD-QC-OLD")).isEqualTo(1);', '.hasMessage("质检必须提供稳定请求编号");\n        assertThat(world.semi("MD-QC-OLD", 1001L)).isEqualByComparingTo("10");\n        assertThat(world.frozen("MD-QC-OLD", 1001L)).isEqualByComparingTo("0");\n        assertThat(world.freezes("MD-QC-OLD")).isZero();')
  s=s.replace('QualityVerdicts.FAIL, "划伤"))), inspector))\n                .isInstanceOf(IllegalStateException.class)', 'QualityVerdicts.FAIL, "划伤"))), inspector))\n                .isInstanceOf(BusinessException.class)')
 f.write_text(s,encoding='utf-8')
f=p/'FormalStockFlowContractTest.java';s=f.read_text(encoding='utf-8').replace('var documents = new InMemoryBusinessDocumentRepository();','var documents = new InMemoryBusinessDocumentRepository();\n        var unit = com.zhubao.erp.business.BusinessWorkFixture.unit(dataSource);').replace('com.zhubao.erp.business.BusinessWorkFixture.unit()', 'unit');f.write_text(s,encoding='utf-8')
f=p/'KeptMotherOperationContextTest.java';s=f.read_text(encoding='utf-8').replace('var stocks = new StockLedgerService(StockRepositoryFixture.create(jdbc));','var dataSource = jdbc ? StockRepositoryFixture.jdbcDataSource() : null;\n        var stocks = new StockLedgerService(jdbc ? new com.zhubao.erp.inventory.infra.JdbcStockLedgerRepository(dataSource) : new com.zhubao.erp.inventory.infra.InMemoryStockLedgerRepository());\n        var unit = com.zhubao.erp.business.BusinessWorkFixture.unit(dataSource);').replace('com.zhubao.erp.business.BusinessWorkFixture.unit()', 'unit').replace('MOTHER, "FINISHED", StockStatus.FINISHED','MOTHER, RAW, StockStatus.FINISHED').replace('"MAT-REAL", "FINISHED", "SHIPPED"','"MAT-REAL", RAW, "SHIPPED"');f.write_text(s,encoding='utf-8')
