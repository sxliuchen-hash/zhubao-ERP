from pathlib import Path
import json,subprocess
f=Path('docs/archive/2026-10-28-slim-implementation/实施记录.md');f.write_text(f.read_text(encoding='utf-8').rstrip()+'\n',encoding='utf-8')
manifest=json.loads(Path('.tools/slim-c3-manifest.json').read_text(encoding='utf-8'))
for p in subprocess.check_output(['git','-c','core.quotepath=false','diff','--name-only'],text=True,encoding='utf-8').splitlines()+subprocess.check_output(['git','-c','core.quotepath=false','ls-files','--others','--exclude-standard'],text=True,encoding='utf-8').splitlines():
 if '/finance/' in p or 'FinanceWorkspace' in p or p.endswith('services/financeApi.ts'):manifest.append(p)
manifest+=['docs/00_项目核心.md','docs/系统级代码瘦身方案.md','docs/archive/2026-10-28-slim-implementation/实施记录.md']
manifest=list(dict.fromkeys(manifest));Path('.tools/slim-batch11-manifest.json').write_text(json.dumps(manifest,ensure_ascii=False),encoding='utf-8')
print('本批文件：',len(manifest))
