from pathlib import Path
import json
rows=json.loads(Path('.tools/slim-css-removed.json').read_text(encoding='utf-8'))
for row in rows:
 if row['retained'] is not None:
  print(row['selector']+' -> '+row['retained'])
