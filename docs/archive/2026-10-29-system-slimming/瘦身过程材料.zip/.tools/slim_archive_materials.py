from pathlib import Path
import hashlib
import json
import re
import subprocess
import zipfile

root = Path(__file__).resolve().parents[1]
archive = root / 'docs/archive/2026-10-29-system-slimming'
assert archive.resolve().is_relative_to(root.resolve())
assert not archive.exists(), '归档目标已存在，停止以免覆盖'
old_report = root / 'docs/系统级代码瘦身方案.md'
new_report = root / 'docs/系统级代码瘦身报告.md'
assert not new_report.exists(), '报告目标已存在'
old = old_report.read_text(encoding='utf-8')
sources = sorted((root / '.tools').glob('slim*'))
sources = [p for p in sources if p.is_file()]
sources += sorted((root / '.tools/__pycache__').glob('slim*.pyc'))
old_dirs = [root / 'docs/archive/2026-10-28-deprecation-audit', root / 'docs/archive/2026-10-28-slim-implementation']
for folder in old_dirs:
    sources += sorted(p for p in folder.rglob('*') if p.is_file())
sources.append(old_report)
assert len(sources) == len(set(sources))
tracked = set(subprocess.check_output(['git', '-c', 'core.quotepath=false', 'ls-files'], cwd=root, text=True, encoding='utf-8').splitlines())
entries = []
payloads = {}
for p in sources:
    assert p.resolve().is_relative_to(root.resolve())
    name = p.relative_to(root).as_posix()
    payload = p.read_bytes()
    payloads[name] = payload
    entries.append({'原路径': name, '字节数': len(payload), 'SHA256': hashlib.sha256(payload).hexdigest(), '原由Git跟踪': name in tracked})

archive.mkdir(parents=True)
bundle = archive / '瘦身过程材料.zip'
with zipfile.ZipFile(bundle, 'x', compression=zipfile.ZIP_DEFLATED) as z:
    for name, payload in payloads.items():
        z.writestr(name, payload)
with zipfile.ZipFile(bundle) as z:
    assert z.testzip() is None
    assert set(z.namelist()) == set(payloads)
    for entry in entries:
        assert hashlib.sha256(z.read(entry['原路径'])).hexdigest() == entry['SHA256']
manifest = {'归档日期': '2026-10-29', '归档文件': bundle.name, '归档SHA256': hashlib.sha256(bundle.read_bytes()).hexdigest(),
            '文件数': len(entries), '原始总字节数': sum(e['字节数'] for e in entries),
            '说明': '按原相对路径保存。材料反映实施时点，停止日常维护，不作为当前执行入口。恢复前在隔离目录核对；现行状态见docs/系统级代码瘦身报告.md。',
            '文件': entries}
(archive / '归档清单.json').write_text(json.dumps(manifest, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')

batch_rows = [line for line in old.splitlines() if re.match(r'^\| \d+／', line)]
assert len(batch_rows) == 14
batch_rows[-1] = batch_rows[-1].replace('14／10-29 增量', '14／`67cb016`')
report = '''# 系统级代码瘦身报告

**更新日期：2026-10-29。已确认方案的源码实施完成，目标环境验收尚未全部关闭。**

## 1. 完成结果

2026-10-28—29 完成十四批瘦身，生产源码累计净减 **7,830 行，约 8.0%**。统计基准为 98,147 行，包含后端 Java、前端 TS／Vue／CSS、打印客户端和安卓生产源码的注释与空行；不含测试、文档、SQL、部署脚本或二进制文件。

10-27 首批 968 行单独留档，不重复计入本轮；并行任务的代码增减和本机原有三个未提交 CSS 文件不计入。代码行数不折算为安装包大小或响应速度。

本次材料整理只归档脚本、调查、清单、日志和过程文档，未新增业务代码减量。按用户最新要求，打印标签相关实现保持不动。最新实施提交为 `67cb016`，本任务未单独部署。

## 2. 已完成范围与保留能力

| 范围 | 已退出内容 | 保留与接续 |
|---|---|---|
| 库存与明细 | 旧备料 HTTP、通用台账 HTTP 写、旧收货／发货 item 双写 | 新 `material-stock` 接口、台账内核、来源行与拆单分配、现行发货记录、锁定读、冲正及事务 |
| 财务 | 旧提前计费、交工重算工资、改单直接记账、损耗工资输入及闲置客户端 | 交货后结单、原账与历史来源、收付款、工资／应付及待结单／历史待核清单 |
| 请求 | 无稳定请求号、无会话业务写回退及旧通用报工链 | HTTP、导入、设备使用真实操作者与原请求；未知结果保留原内容重试，业务与请求结果同事务 |
| 页面与查询 | 六个重复页面、手机专属动作映射、旧手机工作台／汇总接口和独立任务拼装 | 原 17 项授权入口、统一订单列表／详情／动作；设备绑定、物理损耗、附件、扫码、草稿及数据范围 |
| 样例 | DEMO 仓储、seed、filter、演示账号及自动客户／附件／网关样例，伪造设备健康与运维记录 | 正式 LIVE 数据、内存／JDBC 模式、基础字典、有效模板、首次改密管理员和真实探针 |
| 打印（已完成历史范围） | Java 客户端、v1 算法及浏览器正式出纸旁路 | C# 工位、v2、历史快照和核纸；第十四批及本次归档未改打印标签，当前规则以项目核心和打印专题为准 |
| 账号 | 预审批新申请、材料评估／上传、专属审批消费和强制开关 | 管理员直接保存与审计、最后管理员保护、账号／客户授权原子事务、密码策略与会话撤销；历史申请／附件只读 |
| 工具与尾部 | 历史 `check-m0/check-m1`、无调用助手／类型／客户端、失效样式 | 当前检查、业务审计、升级与备份脚本；动态状态类及有效响应式规则 |

数据库历史表、已发布迁移、原账、附件原件与已有账号没有随瘦身删除。进度百分比、正式交工和真实交货分别处理，查询不自动写库存、工资或应收。

## 3. 批次与验证

以下为各批实际结果；测试数量不相加作为去重后的全仓用例数。

| 批次／提交 | 完成范围 | 生产净减（行） | 实际验证 |
|---|---|---:|---|
'''
report += '\n'.join(batch_rows)
report += '''

第十三批前端全量覆盖 95 文件、554 项；首次两项仍按旧选项／文案断言，修正后两文件 10 项重跑通过，复用其余结果。此前六项标签／手机／扫码旧失败已按现行共享组件和操作接续。

第十四批保留千单／万流水的四个现行视图读取次数、结果指纹与客户范围验证。删除两个旧响应后调整指纹并重跑两项，其余 24 项通过结果复用。HTTP 检查确认旧地址返回 404，真实会话客户范围不能被请求头覆盖、空范围不放宽。

## 4. 尚未关闭的验收

| 项目 | 当前缺口 |
|---|---|
| 目标 MySQL | 本次停写旧明细、退售后／库存并发及财务核销等相关目标数据库链路仍须按项目核心核验；内存／H2 结果不替代目标库验收 |
| 真实手机 | 当前版本全链、拍摄上传关联及真实岗位试单仍待验收，正式签名 APK 另行推进 |
| 标签机现场 | 实体出纸清晰度、扫码和换贴仍待现场确认；打印实现不在后续瘦身范围内 |

本报告说明已确认方案的实施结果，不宣称全仓不存在新的精简候选。新的候选须根据实际消费者和保留能力重新调查。

## 5. 归档与恢复入口

本文件是唯一现行瘦身专题。完整调查、原实施方案、十四批过程记录、临时修改／统计脚本、验证日志及清单统一保存为[瘦身过程材料](./archive/2026-10-29-system-slimming/瘦身过程材料.zip)，原路径、字节数及 SHA-256 见[归档清单](./archive/2026-10-29-system-slimming/归档清单.json)。旧脚本停止维护，不自动重跑；按原路径解压可追溯原材料，代码回退通过上述 Git 提交核对。

项目当前范围与其他任务进度仍见[项目核心](./00_项目核心.md)。
'''
new_report.write_text(report, encoding='utf-8')

# 先完成归档字节校验，再逐个移除原件；不递归清空任何目录。
for p in sources:
    p.unlink()
for folder in old_dirs:
    for child in sorted((p for p in folder.rglob('*') if p.is_dir()), key=lambda p: len(p.parts), reverse=True):
        child.rmdir()
    folder.rmdir()

replacements = ['docs/库存管理与母单加工要求模板改造方案.md', 'docs/角色权限与数据范围改造方案.md']
for name in replacements:
    p = root / name
    text = p.read_text(encoding='utf-8').replace('./系统级代码瘦身方案.md', './系统级代码瘦身报告.md')
    if '库存管理' in name:
        text = text.replace('以上是已确定的实施边界，尚未宣称源码已退出。', '相关源码已退出，目标 MySQL 与业务抽样仍按项目核心验收。')
    p.write_text(text, encoding='utf-8')
p = root / 'docs/00_项目核心.md'
lines = p.read_text(encoding='utf-8').splitlines()
lines = [line for line in lines if not line.startswith('| 前端无用代码缩减 |')]
for i, line in enumerate(lines):
    if line.startswith('| 系统级代码瘦身 |'):
        lines[i] = '| 系统级代码瘦身 | 已确认方案完成十四批，生产净减 **7,830 行（约 8.0%）**，最新提交 `67cb016`。目标 MySQL、真实手机与出纸验收仍未关闭；打印标签保持不动。调查、脚本、日志及过程文档已归档，唯一现行专题为[瘦身报告](./系统级代码瘦身报告.md)。 |'
p.write_text('\n'.join(lines) + '\n', encoding='utf-8')
p = root / 'docs/README.md'
text = p.read_text(encoding='utf-8')
needle = '| 跨材质子单限制及下游契约 |'
index = text.index(needle)
text = text[:index] + '| 已完成的系统级瘦身与验收边界 | [瘦身报告](./系统级代码瘦身报告.md)，调查、脚本及过程记录已归档 |\n' + text[index:]
p.write_text(text, encoding='utf-8')
p = root / 'docs/archive/README.md'
text = p.read_text(encoding='utf-8')
needle = '| [2026-10-25-context]'
index = text.index(needle)
text = text[:index] + '| [2026-10-29-system-slimming](./2026-10-29-system-slimming/) | 瘦身调查、原方案、实施记录与临时脚本／日志，按原路径打包并附字节校验清单；现行只保留[瘦身报告](../系统级代码瘦身报告.md) |\n' + text[index:]
p.write_text(text, encoding='utf-8')
print(json.dumps({'归档文件数': len(entries), '归档字节数': bundle.stat().st_size, '原始字节数': manifest['原始总字节数'], '归档SHA256': manifest['归档SHA256']}, ensure_ascii=False))
