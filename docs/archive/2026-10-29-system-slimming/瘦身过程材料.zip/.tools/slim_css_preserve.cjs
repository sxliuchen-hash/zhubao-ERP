process.on('uncaughtException', error => { process.stderr.write(error.message+'\n'); process.exit(1); });
const fs = require('fs');
const path = require('path');
const { createRequire } = require('module');
const workspaceRequire = createRequire(path.resolve('frontend/package.json'));
const viteRequire = createRequire(workspaceRequire.resolve('vite'));
const postcss = viteRequire('postcss');
const rows = JSON.parse(fs.readFileSync('.tools/slim-css-candidates.json', 'utf8'));
const candidates = new Map();
for (const row of rows) {
  if (row['初步边界'].includes('保留')) continue;
  const file = row['文件'];
  if (!candidates.has(file)) candidates.set(file, new Set());
  candidates.get(file).add(row['类名']);
}
// 旧页面专属容器及布局已失去运行时消费者，组合选择器中仍使用的部分逐项保留。
const retired = new Set([...JSON.parse(fs.readFileSync('.tools/slim-css-extra.json', 'utf8')), 'inbound-desk', 'production-desk', 'quality-desk', 'progress-board', 'inbound-dispatch-table', 'production-dispatch-table', 'quality-dispatch-table', 'progress-table', 'inbound-card', 'progress-card', 'order-legacy-actions', 'order-legacy-pages']);
const runtime = [];
function walk(dir) {
  for (const entry of fs.readdirSync(dir, { withFileTypes: true })) {
    const file = path.join(dir, entry.name);
    if (entry.isDirectory()) walk(file);
    else if (/\.(vue|ts)$/.test(file) && !/\.test\.ts$/.test(file)) runtime.push(fs.readFileSync(file, 'utf8').replace(/<style\b[^>]*>[\s\S]*?<\/style>/g, ''));
  }
}
walk('frontend/src');
const escaped = name => name.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
for (const name of retired) if (runtime.some(text => new RegExp('(?<![\\w-])'+escaped(name)+'(?![\\w-])').test(text))) throw new Error('旧容器仍有运行时消费者：'+name);
function masked(selector) {
  return selector.replace(/\[[^\]]*\]|"(?:\\.|[^"\\])*"|'(?:\\.|[^'\\])*'|\/\*[\s\S]*?\*\//g, match => ' '.repeat(match.length));
}
function prune(selector, dead) {
  const hasDead = text => [...dead].some(name => new RegExp('\\.'+escaped(name)+'(?![\\w-])').test(masked(text)));
  const scan = masked(selector);
  const functions = /:([a-zA-Z-]+)\(/g;
  let result = '', cursor = 0, match;
  while ((match = functions.exec(scan))) {
    const before = selector.slice(cursor, match.index);
    if (hasDead(before)) return null;
    let end = functions.lastIndex, depth = 1;
    while (end < scan.length && depth) { if (scan[end] === '(') depth++; else if (scan[end] === ')') depth--; end++; }
    if (depth) throw new Error('选择器括号不完整：'+selector);
    const body = selector.slice(functions.lastIndex, end - 1);
    if (['is', 'where'].includes(match[1])) {
      const branches = postcss.list.comma(body).map(part => prune(part, dead)).filter(Boolean);
      if (!branches.length) return null;
      result += before + ':' + match[1] + '(' + branches.join(', ') + ')';
    } else {
      if (hasDead(body)) throw new Error('特殊伪类需人工核对：'+selector);
      result += before + selector.slice(match.index, end);
    }
    cursor = end; functions.lastIndex = end;
  }
  const tail = selector.slice(cursor);
  return hasDead(tail) ? null : result + tail;
}
function rawBranches(selector) {
  const scan = masked(selector); let depth = 0, start = 0; const parts = [];
  for (let i = 0; i < scan.length; i++) {
    if (scan[i] === '(') depth++;
    else if (scan[i] === ')') depth--;
    else if (scan[i] === ',' && depth === 0) { parts.push(selector.slice(start, i)); start = i + 1; }
  }
  parts.push(selector.slice(start)); return parts;
}
const plans = [];
const removed = [];
for (const file of fs.readdirSync('frontend/src').filter(name => name.endsWith('.css')).map(name => 'frontend/src/'+name)) {
  const dead = new Set([...(candidates.get(file) || []), ...retired]);
  const original = require('child_process').execFileSync('git', ['show', 'HEAD:'+file], { encoding: 'utf8' });
  const root = postcss.parse(original, { from: file });
  root.walkRules(rule => {
    const parts = rawBranches(rule.selector);
    const keep = parts.map(selector => {
      const next = prune(selector, dead);
      if (next !== selector) removed.push({ file, selector, retained: next });
      return next;
    }).filter(Boolean);
    if (keep.length === parts.length && keep.every((selector, i) => selector === parts[i])) return;
    if (keep.length) rule.selector = keep.join(',').trim(); else rule.remove();
  });
  root.walkAtRules(rule => { if (rule.nodes && !rule.nodes.some(node => node.type !== 'comment')) rule.remove(); });
  const after = root.toString(); postcss.parse(after);
  plans.push([file, after]);
}
if (process.argv.includes('--apply')) for (const [file, text] of plans) fs.writeFileSync(file, text);
fs.writeFileSync('.tools/slim-css-removed.json', JSON.stringify(removed, null, 2));
process.stdout.write(JSON.stringify({ selectors: removed.length, files: [...new Set(removed.map(row => row.file))] })+'\n');
