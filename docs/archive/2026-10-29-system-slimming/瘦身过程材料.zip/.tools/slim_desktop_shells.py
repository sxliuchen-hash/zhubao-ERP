from pathlib import Path
f=Path('frontend/src/features/orders/OrderWorkspace.vue');s=f.read_text(encoding='utf-8').replace('computed, inject, nextTick', 'computed, defineAsyncComponent, inject, nextTick').replace("import { workspaceTabs } from '../workspace/workspaceNavigation';\n",'')
a=s.index('const legacyTabs');b=s.index('const serverViews',a);s=s[:a]+"const MachineOutputPanel = defineAsyncComponent(() => import('../production/MachineOutputPanel.vue'));\nconst machineToolsCreated = ref(false);\n"+s[b:]
a=s.index('      <details class="order-legacy-pages">');b=s.index('\n',a);s=s[:a]+s[b+1:]
s=s.replace('    </section>\n    <aside v-if="detailOpen"', '''      <details v-if="view === 'PRODUCTION' && tabs.includes('production')" class="section-block" @toggle="($event.target as HTMLDetailsElement).open && (machineToolsCreated = true)">
        <summary>设备产量与机器档案绑定</summary><MachineOutputPanel v-if="machineToolsCreated" />
      </details>
    </section>
    <aside v-if="detailOpen"''')
f.write_text(s,encoding='utf-8')
f=Path('frontend/src/App.vue');s=f.read_text(encoding='utf-8')
for name in ['InboundWorkspace','ProductionWorkspace','ProgressWorkspace','QualityWorkspace']:
 s=s.replace("() => import('./features/m1/"+name+".vue')",'orderWorkspaceLoader')
s=s.replace("function activateTab(tab: TabKey) {\n  if (visibleTabs.value.some((item) => item.key === tab)) {", "function activateTab(tab: TabKey) {\n  if (!visibleTabs.value.some(item => item.key === tab)) return;\n  if (['inbound', 'production', 'progress', 'quality'].includes(tab)) {\n    openOrders(tab === 'quality' ? 'QUALITY' : tab === 'inbound' ? 'ORDERS' : 'PRODUCTION');\n    return;\n  }\n  if (visibleTabs.value.some((item) => item.key === tab)) {")
f.write_text(s,encoding='utf-8')
f=Path('frontend/src/features/scan/ChainReview.vue');s=f.read_text(encoding='utf-8');i=s.index("const openTab = inject");s=s[:i]+"const openIntake = inject<((target: { objectType: NonNullable<ScanContextResponse['target']['objectType']>; code: string }) => void) | null>('zhubao-open-intake', null);\n"+s[i:]
s=s.replace("  if (intent === 'PRODUCTION' && openProduction)","  if (intent === 'INTAKE' && openIntake) { openIntake({ objectType: target.objectType, code: target.code }); return; }\n  if (intent === 'PRODUCTION' && openProduction)")
# 复用已有导入的扫码对象类型。
s=s.replace("NonNullable<ScanContextResponse['target']['objectType']>","NonNullable<ReturnType<typeof canonicalTarget>>['objectType']")
f.write_text(s,encoding='utf-8')
# 旧页面外壳退出，原路径仍可从提交历史恢复。
for name in ['InboundWorkspace','ProductionWorkspace','ProgressWorkspace','QualityWorkspace']:
 Path('frontend/src/features/m1/'+name+'.vue').unlink()
