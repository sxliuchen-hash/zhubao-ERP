from pathlib import Path
import re
from slim_helpers import mask, remove

root = Path('backend/src/main/java/com/zhubao/erp/business')
p = root / 'web/BusinessWorkspaceController.java'
s = p.read_text(encoding='utf-8')
for name in ('BusinessWorkspaceSummary', 'MobileWorkspaceData'):
    s = re.sub(r'^import .*\.' + name + r';\n', '', s, flags=re.M)
s = re.sub(r'\n    @GetMapping\("/mobile"\)[\s\S]*\n}\s*$', '\n}\n', s)
p.write_text(s, encoding='utf-8')

p = root / 'app/BusinessWorkspaceService.java'
s = p.read_text(encoding='utf-8')
s = re.sub(r'    public MobileWorkspaceData mobile\(\)[\s\S]*\n}\s*$', '}\n', s)
p.write_text(s, encoding='utf-8')

p = root / 'app/FormalBusinessWorkspaceQuery.java'
s = p.read_text(encoding='utf-8')
s = remove(s, 'summary', 'BusinessWorkspaceSummary') if False else s
start = s.index('    BusinessWorkspaceSummary summary(')
end = s.index('    InboundWorkspaceData inbound(', start)
s = s[:start] + s[end:]
start = s.index('    MobileWorkspaceData mobile(')
end = s.index('    private InboundWorkspaceData inbound(', start)
s = s[:start] + s[end:]
s = remove(s, 'mobile')
s = re.sub(r'^            case MOBILE, SUMMARY -> .*\n', '', s, flags=re.M)
s = s.replace('"mobile".equals(area) ? row.openTab() : area', 'area')
s = s.replace('INBOUND, PRODUCTION, QUALITY, INVENTORY, MOBILE, SUMMARY', 'INBOUND, PRODUCTION, QUALITY, INVENTORY')
p.write_text(s, encoding='utf-8')

p = root / 'domain/BusinessReviewData.java'
s = p.read_text(encoding='utf-8')
s = re.sub(r'    public record MobileTask[^\n]*\n    }\n\n', '', s)
start = s.index('    public record MobileWorkspaceData(')
s = s[:start] + '}\n'
p.write_text(s, encoding='utf-8')

p = Path('frontend/src/services/documentCaptureApi.ts')
p.unlink()
for name in ('BusinessWorkspaces.test.ts', 'scanTargetGuard.test.ts'):
    p = Path('frontend/src/features/m1') / name
    s = p.read_text(encoding='utf-8')
    s = re.sub(r"vi.mock\('../../services/documentCaptureApi', \(\) => \(\{[\s\S]*?\}\)\);\n\n?", '', s)
    p.write_text(s, encoding='utf-8')

p = Path('backend/src/test/java/com/zhubao/erp/business/app/FormalBusinessWorkspaceQueryTest.java')
s = p.read_text(encoding='utf-8')
s = s.replace('assertThat(service.summary().dataSource()).isEqualTo("LIVE");', 'assertThat(service.inbound().dataSource()).isEqualTo("LIVE");')
s = s.replace('assertThat(service.summary().inboundOrders()).isZero();', 'assertThat(service.inbound().orders()).isEmpty();')
s = re.sub(r'^        assertThat\(service.mobile\(\).*\n', '', s, flags=re.M)
p.write_text(s, encoding='utf-8')

p = Path('backend/src/test/java/com/zhubao/erp/business/app/FormalBusinessWorkspaceQueryLoadTest.java')
s = p.read_text(encoding='utf-8')
for name in ('BusinessWorkspaceSummary', 'MobileWorkspaceData'):
    s = re.sub(r'^import .*\.' + name + r';\n', '', s, flags=re.M)
s = s.replace('        service.summary();', '        service.inbound();\n        service.production();\n        service.quality();\n        service.inventory();')
s = re.sub(r'^        BusinessWorkspaceSummary\[\].*\n|^        readings.put\("summary".*\n|^        MobileWorkspaceData mobile;\n', '', s, flags=re.M)
start = s.index('        documentCalls.clear();', s.index('readings.put("inventory"'))
end = s.index('        String fingerprint =', start)
s = s[:start] + s[end:]
s = s.replace('fingerprint(summaryHolder[0], inbound, production, quality, inventory, mobile)', 'fingerprint(inbound, production, quality, inventory)')
start = s.index('        assertThat(readings.get("summary")')
end = s.index('        assertThat(readings.get("inbound")', start)
s = s[:start] + s[end:]
s = re.sub(r'^        assertThat\(readings.get\("mobile"\).*\n|^            assertThat\(rangedService\.(?:mobile|summary)\(.*\n', '', s, flags=re.M)
s = remove(s, 'read')
s = s.replace('fingerprint(BusinessWorkspaceSummary summary, InboundWorkspaceData inbound,', 'fingerprint(InboundWorkspaceData inbound,')
s = s.replace('InventoryWorkspaceData inventory, MobileWorkspaceData mobile)', 'InventoryWorkspaceData inventory)')
s = s.replace('        add(digest, summary);\n', '').replace('        add(digest, mobile);\n', '')
s = s.replace('one warmup summary then one timed call per entry', 'one warmup per active entry then one timed call per entry')
p.write_text(s, encoding='utf-8')
