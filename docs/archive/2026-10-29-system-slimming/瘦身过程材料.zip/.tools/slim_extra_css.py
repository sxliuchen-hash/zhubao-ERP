from pathlib import Path
import subprocess,re,json
pages=['InboundWorkspace','ProductionWorkspace','ProgressWorkspace','QualityWorkspace','MobileOpsWorkspace','MobileOrderDetail']
classes=set()
for name in pages:
 source=subprocess.check_output(['git','show','7f4e2e5:frontend/src/features/m1/'+name+'.vue'],text=True,encoding='utf-8')
 for m in re.finditer(r'(?<!:)class="([^"]+)"',source):
  classes.update(c for c in m[1].split() if re.fullmatch(r'[a-z][\w-]*',c))
runtime=[]
for p in Path('frontend/src').rglob('*'):
 if p.suffix not in ['.ts','.vue'] or p.name.endswith('.test.ts'):continue
 runtime.append(re.sub(r'<style\b[^>]*>[\s\S]*?</style>','',p.read_text(encoding='utf-8')))
css='\n'.join(p.read_text(encoding='utf-8') for p in Path('frontend/src').glob('*.css'))
extra=[]
for c in sorted(classes):
 if c.startswith(('tone-','is-')):continue
 pattern=r'(?<![\w-])'+re.escape(c)+r'(?![\w-])'
 if not any(re.search(pattern,t) for t in runtime) and re.search(r'\.'+re.escape(c)+r'(?![\w-])',css):extra.append(c)
print(json.dumps(extra))
Path('.tools/slim-css-extra.json').write_text(json.dumps(extra),encoding='utf-8')
