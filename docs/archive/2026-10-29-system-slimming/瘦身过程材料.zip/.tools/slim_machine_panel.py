from pathlib import Path
import textwrap
p=Path('frontend/src/features/m1/ProductionWorkspace.vue');s=p.read_text(encoding='utf-8')
a=s.index('const machineOutputSummary = ref');b=s.index('const activeWorkOrder',a);state=s[a:b]
a=s.index('const machineOutputTopMachines');b=s.index('onMounted(',a);computed=s[a:b]
a=s.index('async function loadMachineOutputSummary()');b=s.index('function workOrderTone',a);functions=s[a:b]
a=s.index('function outputQuantityText');b=s.index('</script>',a);helpers=s[a:b]
a=s.index('        <div class="section-block module-rule-panel machine-output-summary-panel">');b=s.index('      </section>',a);template=textwrap.dedent(s[a:b]).strip()
header='''<script setup lang="ts">
import { computed, inject, onMounted, ref, type Ref } from 'vue';
import StatusBadge from '../../components/StatusBadge.vue';
import type { AuthSession } from '../../services/authApi';
import type { Tone } from '../../data/m1PrototypeData';
import { bindMachineOutput, fetchMachineOutputMachineMatchSuggestions, fetchMachineOutputSummary,
  type MachineOutputMachineMatchSuggestion, type MachineOutputSummary } from '../../services/machineOutputApi';
const session = inject<Ref<AuthSession | null>>('zhubao-auth-session', ref(null));
const canBind = computed(() => !session.value?.effectivePermissions || session.value.effectivePermissions.includes('MACHINE_OUTPUT_SUBMIT'));
const binding = ref(false);
'''
functions=functions.replace("  machineBindMessage.value = '';\n  const machineId", "  if (!canBind.value || binding.value || item.readiness !== 'READY_TO_BIND' || item.candidateMachineIds.length !== 1) return;\n  machineBindMessage.value = '';\n  const machineId")
functions=functions.replace('  try {\n    const result = await bindMachineOutput', '  binding.value = true;\n  try {\n    const result = await bindMachineOutput')
functions=functions.replace("    machineBindMessage.value = error instanceof Error ? error.message : '机器档案绑定失败';\n  }", "    machineBindMessage.value = error instanceof Error ? error.message : '机器档案绑定失败';\n  } finally { binding.value = false; }")
template=template.replace("v-if=\"item.readiness === 'READY_TO_BIND'\"", "v-if=\"canBind && item.readiness === 'READY_TO_BIND' && item.candidateMachineIds.length === 1\"\n          :disabled=\"binding\"")
template=template.replace('<h2>设备产量汇总</h2>', '<h2>设备产量汇总</h2><button type="button" class="secondary-button" :disabled="machineOutputSummaryLoading || binding" @click="reload">刷新设备统计与匹配建议</button>')
source=header+state+computed+"onMounted(reload);\nfunction reload() { void loadMachineOutputSummary(); void loadMachineMatchSuggestions(); }\n"+functions+helpers+'</script>\n\n<template>\n'+template+'\n</template>\n'
Path('frontend/src/features/production/MachineOutputPanel.vue').write_text(source,encoding='utf-8')
