from pathlib import Path
import re,json,subprocess
f=Path('docs/00_项目核心.md');s=f.read_text(encoding='utf-8').replace('保留 `App.vue` 原 17 页及依赖','保留 `App.vue` 原 17 项授权入口及业务依赖').replace('`features/intake/`、`features/m1/{InboundWorkspace,MotherSplitPanel}.vue`','`features/intake/`、`features/m1/MotherSplitPanel.vue`').replace('接口在 `services/*Api.ts`，`MobileOpsWorkspace.vue` 仍复用共用面板。','接口在 `services/*Api.ts`。来料、生产、进度、质量及手机入口统一使用 `features/orders/OrderWorkspace.vue`、共享详情与 `OrderActionHost`；设备汇总在生产视图工具中，物理损耗在单内质量办理中按需打开。')
s=re.sub(r'^\| 系统级代码瘦身 \|.*$', '| 系统级代码瘦身 | 前十二批生产源码累计净减 **7,552 行**（约调查基准的 7.7%）。旧链路、样例、旧打印与账号预审批已退出；稳定请求、退售后／损耗审批、待结单清单已接续。六个重复页面实现退出，桌面／手机统一列表、详情和动作，设备绑定、物理损耗、收货附件／拆单、扫码和草稿仍可办理；两种查询共用正式交工位置，进度百分比和交货事实分别保留。第十二批后端 25 项、前端 81 项及类型检查通过。剩余失效样式、少量无调用助手与最终引用核对继续；目标 MySQL、真实手机及出纸验收仍未关闭，未单独部署。范围与验证见[最终报告](./系统级代码瘦身方案.md#21-已完成与已有实现)及[实施记录](./archive/2026-10-28-slim-implementation/实施记录.md)。 |',s,flags=re.M)
f.write_text(s,encoding='utf-8')
f=Path('docs/系统级代码瘦身方案.md');s=f.read_text(encoding='utf-8').replace('前十一批实际净减 5,970 行','前十二批实际净减 7,552 行').replace('第 1—11 批','第 1—12 批').replace('**5,970 行**，约占调查基准的 **6.1%**','**7,552 行**，约占调查基准的 **7.7%**').replace('| 11／10-29 增量 |','| 11／`7f4e2e5` |')
row='| 12／10-29 增量 | 六个页面实现退出，统一桌面／手机查询、详情与动作，迁移设备绑定和物理损耗，共用正式交工位置 | 1,582 | 后端 25 项、前端 81 项、类型检查 |'
a=s.index('\n后续接续状态');s=s[:a].rstrip()+'\n'+row+'\n'+s[a:]
s=re.sub(r'^\| 尚未实施完成 \| B4—B6.*\n','',s,flags=re.M).replace('第 11 批已完成上述请求与清单接续，仍需继续页面与尾部清理。','第 11、12 批已完成请求、清单及页面／查询接续，尾部清理继续。')
f.write_text(s,encoding='utf-8')
f=Path('docs/archive/2026-10-28-slim-implementation/实施记录.md');s=f.read_text(encoding='utf-8').replace('前十一批完成定向验证，生产源码累计净减 **5,970 行**。第 11 批统一稳定请求并接续待结单／历史待核查询；剩余页面／查询、样式与尾部清理继续。','前十二批完成定向验证，生产源码累计净减 **7,552 行**。稳定请求、待结单清单及页面／查询接续完成，样式与尾部清理继续。')
s+='''
## 第 12 批：统一桌面、手机与查询事实

- App 的来料、生产、进度、质量及手机菜单保留原授权身份，实际统一 `OrderWorkspace`。退出六个旧页面实现及手机专属角色／动作映射；快捷操作按真实菜单和服务端有效权限开放，继续调用全局缓存的 `OrderActionHost`，不再在页内新建第二份业务表单。
- 设备产量、机器匹配与人工绑定迁入按需读取的 `MachineOutputPanel`；读取失败有明确状态和重试，候选唯一且有权限才能绑定，提交中禁止重复绑定。物理损耗迁入共享质量办理，按原质量接口取得本单唯一来源；缓存面板关闭再开仍保留原请求。
- 收货、待核、稍后拆、现有母单证据与标签继续由 `IntakePanel/MotherSplitPanel` 和共享动作接续。追溯收货转共享容器；扫码、人工选择、手输和过程说明继续使用现行共用组件。工作台仍使用来料／生产读取，客户档案仍用进度查询，相关 API 与实际 mapper 保留，不能因旧页面退出删除。
- 手机菜单可读同一 `ORDERS` 视图，客户／本人等数据范围不变；生产、质量专门视图继续要求相应菜单。空范围与空菜单拒绝仍验证。只有手机菜单时也直接落到统一订单页，不回到旧页。
- `WorkshopProcesses.current` 只共用正式交工位置；订单中心的五档进度、分批到达数量、轮次／交货事实及进度看板的展示差异仍各自处理，不以百分比代替交工。
- 旧页面表格、旧手机页内分发与本地确认步骤的专属测试退出；其查询、分页／筛选、精确母子单／轮次、迟到响应、返回、有效权限与动作容器场景由共享列表／App／容器测试覆盖。质检防串单、退货重量确认、首次损耗申请和扫码暂停等实际业务测试迁到真实共享组件，未删除业务场景。旧无请求号、旧确认按钮及假探针期望按现行流程接续。
- 生产源码净减 **1,582 行**，不把退出的外壳测试计入减量。后端 `OrderWorkspaceQueryServiceTest/OrderWorkspaceControllerTest/ProgressBoardServiceTest/FormalBusinessWorkspaceQueryTest` 共 25 项通过；前端十文件分轮共 81 项通过，类型检查通过。后续全量前端及生产装配检查在尾部清理后执行。
'''
f.write_text(s,encoding='utf-8')
f=Path('docs/16_字段字典与API契约.md');s=f.read_text(encoding='utf-8').replace('没有来料、进度、生产、质检或库存菜单时拒绝，不把无权限变成空页。','来料、进度、生产、质检、库存或手机菜单可读取 `ORDERS`；只有手机菜单时不开放 `PRODUCTION/QUALITY` 专门视图。所有视图继续执行原客户／本人／班组／部门范围；没有这些菜单时拒绝，不把无权限变成空页。');f.write_text(s,encoding='utf-8')
f=Path('docs/角色权限与数据范围改造方案.md');s=f.read_text(encoding='utf-8');needle='桌面、手机与以后安卓端使用同一服务端授权；菜单和按钮只反映授权结果，不能充当授权依据。';s=s.replace(needle,needle+' 10-29 桌面与手机已统一订单列表、详情及动作容器；手机菜单可读取 `ORDERS`，生产／质量专门视图仍需对应菜单。快捷操作依据 `effectivePermissions` 和菜单，服务端继续逐请求验证角色及数据范围。');f.write_text(s,encoding='utf-8')
manifest=subprocess.check_output(['git','-c','core.quotepath=false','diff','--name-only'],text=True,encoding='utf-8').splitlines()+subprocess.check_output(['git','-c','core.quotepath=false','ls-files','--others','--exclude-standard'],text=True,encoding='utf-8').splitlines();Path('.tools/slim-batch12-manifest.json').write_text(json.dumps(list(dict.fromkeys(manifest)),ensure_ascii=False),encoding='utf-8')
