from pathlib import Path
f=Path('docs/16_字段字典与API契约.md');s=f.read_text(encoding='utf-8')
s=s.replace('可选。同一次确认保持不变，8 到 64 位，只含字母、数字、点、下划线、冒号和减号。不传时仍走旧的各自提交，不回放','必填。同一次确认及未知结果重试保持不变，8 到 64 位，只含字母、数字、点、下划线、冒号和减号；缺失直接拒绝')
a=s.index('- 不带 `requestId` 的旧调用，以及登记导入调用的确认入库');b=s.index('\n',a)
s=s[:a]+'- 收货、工序交付、质检及发货统一稳定请求与业务工作单元；缺少请求号或工作单元直接拒绝。导入沿用批次行原编号，设备报工沿用 `gw-report-` 读数编号；来料建单在已有会话内入库，不嵌套工作单元。旧通用报工及质检 HTTP 不再开放。'+s[b:]
s=s.replace('不带 `requestId` 时质检面板仍各自提交，不回放。','缺少 `requestId` 时直接拒绝，不再保留各自提交路径。')
a=s.index('- 不带 `requestId` 的旧调用仍由库存仓储');b=s.index('\n',a)
s=s[:a]+'- 缺少 `requestId` 直接拒绝，出库单保存失败整单回滚。出货单唯一键沿用 V14，请求表沿用 V44；只写现行 `biz_outbound_order` 与台账，旧 item 双写已退出，历史表和迁移保留。'+s[b:]
s=s.replace('该接口是 损耗审批与工资试算基线，目标是先冻结损耗归因和工资试算口径，不接入正式审批流，不写库存台账。','该接口记录实物损耗并创建轻量审批任务，不写库存、收入或工资。稳定请求结果、任务及 JDBC 审计在同一次事务提交。')
s=s.replace('| `approvalCode` | 损耗审批单号，作为审批/试算快照编码 |','| `approvalCode` | 损耗申请单号；新请求不能覆盖既有申请或审批决定 |')
s=s.replace('| `acceptedQuantity` | 合格计件数量，用于工资试算 |','| `acceptedQuantity` | 历史兼容字段，可不传；新表单不再采集 |').replace('| `pieceRate` | 工序计件单价快照 |','| `pieceRate` | 历史兼容字段，不参与本次损耗计算 |').replace('| `lossDeductionUnitPrice` | 超标损耗每克扣款单价快照 |','| `lossDeductionUnitPrice` | 历史兼容字段，不参与本次损耗计算 |')
s=s.replace('| `acceptedQuantity` | 合格计件数量，按整数返回 |','| `acceptedQuantity` | 兼容原输入的可空数量，存在时按 3 位小数返回 |').replace('| `pieceRate` | 计件单价快照，按 2 位小数返回 |','| `pieceRate` | 新申请返回 null，保留历史响应兼容 |').replace('| `pieceWage` | 计件工资，`acceptedQuantity * pieceRate` |','| `pieceWage` | 新申请返回 null，交货后结单确定工资 |').replace('| `lossDeduction` | 损耗扣款，`min(excessLossWeight * lossDeductionUnitPrice, pieceWage)` |','| `lossDeduction` | 新申请返回 null，不自动扣款 |').replace('| `trialWage` | 工资试算，`max(0, pieceWage - lossDeduction)` |','| `trialWage` | 新申请返回 null，不再试算工资 |')
a=s.index('- 该接口会在 生成轻量审批任务');b=s.index('\n---',a)
s=s[:a]+'''- 新申请与原请求结果同次提交；同账号同请求同内容回放，改变内容拒绝。不同请求不能使用同一申请单号覆盖既有任务。
- 损耗重量及标准率仍用于实物归因，工资和客户费用由交货后结单另行确认；不从损耗申请自动记账。
- JDBC 业务工作单元需搭配 JDBC 审批仓储；混用内存审批仓储时拒绝新申请，避免事务回滚后遗留任务。
'''+s[b:]
for heading in ['### 6.11 `ApproveLossCommand`','### 7.6 `CustomerReturnCommand`','### 7.7 `AfterSalesReviewCommand`']:
 a=s.index(heading);b=s.index('\n### ',a+5)
 part=s[a:b].replace('| `remark` | 备注 |','| `remark` | 备注 |\n| `requestId` | 必填稳定请求号；同次确认及未知结果重试保持不变 |',1)
 if '7.' in heading:part+='\n退售后统一使用真实会话身份和业务工作单元，缺少请求号或装配直接拒绝；同账号同请求同内容回放原台账号，改变内容拒绝。母单锁取得后当前读核对原业务单号，另换请求号也不能重复入账。库存与请求结果同次提交，保存失败回滚。\n'
 s=s[:a]+part+s[b:]
s=s.replace('生成损耗审批与工资试算快照，并创建轻量审批任务；不写库存台账，不代表正式工资发放','记录物理损耗并创建轻量审批任务；原请求可回放，不写库存或工资').replace('返回损耗审批与工资试算快照，并创建轻量审批任务；不写库存台账','返回实物损耗计算并创建轻量审批任务；不写库存或工资')
s=s.replace('兼容显式申请接口仍可生成独立 `ACCOUNT_PRE_APPROVAL` 场景任务。','账号预审批新申请及消费链已退出，已有账号场景任务仅按原授权保留历史读取。').replace('兼容显式申请的 `ACCOUNT_PRE_APPROVAL`','历史 `ACCOUNT_PRE_APPROVAL`')
a=s.index('| 结构化出库单 |');b=s.index('\n',a);s=s[:a]+'| 结构化出库单 | `POST /api/business/operations/outbound-shipments`。`requestId` 必填，库存、现行 `biz_outbound_order` 和成功结果同次提交；重复出库单号由唯一键拒绝，旧 item 不再写入 |'+s[b:]
s=s.replace('未带 `requestId` 的旧质检调用、通用 `production-reports` 和确认发货仍各自提交。','缺少稳定请求的旧写入回退已退出；通用 `production-reports` HTTP 已退出。')
f.write_text(s,encoding='utf-8')
for name in ['ProcessStationReportCommand','ShipFinishedStockCommand']:
 f=Path(f'backend/src/main/java/com/zhubao/erp/business/domain/{name}.java');s=f.read_text(encoding='utf-8').replace('requestId 可空。有值时同一次确认回放；不传则仍走各自提交，不回放。','requestId 必填，同一次确认及重试保持不变；缺失直接拒绝。').replace('旧调用不带请求编号。这种调用不回放，也不进入业务工作单元。','兼容旧构造器仅用于缺少请求编号的拒绝校验，不能写入。');f.write_text(s,encoding='utf-8')
