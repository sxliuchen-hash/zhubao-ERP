from pathlib import Path
import subprocess,re
f=Path('backend/src/main/java/com/zhubao/erp/business/app/BusinessCommandActors.java');s=f.read_text(encoding='utf-8');original=subprocess.check_output(['git','show','HEAD:'+f.as_posix()],text=True,encoding='utf-8');m=re.search(r'    public static ReportProductionCommand withActor\([\s\S]*?\n    }\n\n',original);assert m
s=s.replace('    public static ShipFinishedStockCommand',m[0]+'    public static ShipFinishedStockCommand',1);f.write_text(s,encoding='utf-8')
