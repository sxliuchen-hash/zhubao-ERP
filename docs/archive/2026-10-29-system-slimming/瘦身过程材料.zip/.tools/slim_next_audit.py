from pathlib import Path
import re

files = [p for p in Path('frontend/src').rglob('*') if p.suffix in ('.ts', '.vue')
         and not p.name.endswith('.test.ts') and '/test/' not in p.as_posix() and '/vendor/' not in p.as_posix()]
texts = {p: p.read_text(encoding='utf-8') for p in files}
print('运行时文件', len(files))
for p, source in texts.items():
    if any(t in p.as_posix().lower() for t in ('label', 'print', 'qrcode')):
        continue
    for match in re.finditer(r'export\s+(?:async\s+)?(function|const|class|interface|type)\s+(\w+)', source):
        kind, name = match.groups()
        pattern = re.compile(r'\b' + re.escape(name) + r'\b')
        if not any(pattern.search(text) for q, text in texts.items() if q != p):
            print(f'{p.as_posix()}:{source[:match.start()].count(chr(10)) + 1} {kind} {name} local={len(pattern.findall(source))}')

for p in Path('backend/src/main/java').rglob('*.java'):
    if '/label/' in p.as_posix():
        continue
    source = p.read_text(encoding='utf-8')
    masked = re.sub(r'"(?:\\.|[^"\\])*"|//[^\n]*|/\*[\s\S]*?\*/', lambda m: ' ' * len(m[0]), source)
    for match in re.finditer(r'\bprivate\s+(?:static\s+)?(?:final\s+)?[\w<>?, .\[\]]+?\s+(\w+)\s*\(', masked):
        name = match[1]
        if len(re.findall(r'\b' + re.escape(name) + r'\b', masked)) == 1:
            print(f'{p.as_posix()}:{source[:match.start()].count(chr(10)) + 1} private {name}')
