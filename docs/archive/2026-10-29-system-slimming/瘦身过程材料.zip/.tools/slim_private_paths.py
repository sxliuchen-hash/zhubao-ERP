from pathlib import Path
p=Path('backend/src/main/java/com/zhubao/erp/business/app')
f=p/'ProcessStationService.java';s=f.read_text(encoding='utf-8').replace('同账号、同请求、同规范化内容回放原结果。未带编号时仍各自提交，不回放。','同账号、同请求、同规范化内容回放原结果；缺少编号直接拒绝。')
s=s.replace('''        StockLedgerEntry entry = session == null
                ? stockLedgerService.transfer(transfer)
                : stockLedgerService.transfer(transfer, session);''','''        StockLedgerEntry entry = stockLedgerService.transfer(transfer, session);''')
s=s.replace('''        if (session == null) {
            documents.saveProcessStationHandoff(handoff);
        } else {
            documents.saveProcessStationHandoff(handoff, session);
        }''','''        documents.saveProcessStationHandoff(handoff, session);''')
s=s.replace('''        if (session == null) {
            stockLedgerService.transfer(move);
        } else {
            stockLedgerService.transfer(move, session);
        }''','''        stockLedgerService.transfer(move, session);''')
f.write_text(s,encoding='utf-8')
f=p/'QualityRequirementService.java';s=f.read_text(encoding='utf-8').replace(' * 未带请求编号时，库存和质检事实仍各自提交，不回放。',' * 缺少稳定请求编号直接拒绝，库存和质检事实不能各自提交。')
for method,var in [('saveQualityRequirementCheck','check'),('saveQualityRound','round'),('saveQualityReworkReport','report')]:
 s=s.replace(f'''        if (session == null) {{
            documents.{method}({var});
            return;
        }}\n''','')
s=s.replace('''        if (session == null) {
            documents.attachQualityRework(orderCode, reworkOrderCode);
            return;
        }
''','');f.write_text(s,encoding='utf-8')
f=Path('backend/src/main/java/com/zhubao/erp/work/app/JdbcBusinessWorkUnit.java');s=f.read_text(encoding='utf-8').replace(' * 未带请求编号的岗位交付、通用报工、质检旧调用、确认发货和登记导入若仍调用各自新建连接的保存方法，不会进入本事务。',' * 业务写入统一要求稳定请求；库存、单据与审批等 JDBC 写入必须使用本连接，不能另开连接提交。');f.write_text(s,encoding='utf-8')
f=Path('frontend/src/features/m1/BusinessWorkspaces.test.ts');s=f.read_text(encoding='utf-8')
s=s.replace("expect(wrapper.text()).toContain('勾选不是报工');", "expect(wrapper.text()).toContain('点击下方“确认交工”才会提交');")
s=s.replace("    await wrapper.get('[aria-label=\"完成核对\"]').trigger('click');\n    expect(submitProcessStation).not.toHaveBeenCalled();\n    expect(wrapper.text()).toContain('提交雕刻');", "    expect(wrapper.get('[aria-label=\"确认雕刻交工\"]').element).toHaveProperty('disabled', false);\n    expect(submitProcessStation).not.toHaveBeenCalled();")
a=s.index("  it('shows the server rejection when the previous station is not handed in'");b=s.index("  it(",a+6)
part=s[a:b];start=part.index("    await wrapper.get('[aria-label=\"核对 1 内壁刻字\"]').setValue(true);");end=part.index("    expect(wrapper.text()).not.toContain('提交雕刻');",start)
part=part[:start]+'''    expect(wrapper.text()).toContain('上一道「雕刻」还未交工，当前不能提交「镶嵌」');
    expect(wrapper.find('[aria-label="核对 1 内壁刻字"]').exists()).toBe(false);
    const submit = wrapper.get('[aria-label="确认镶嵌交工"]');
    expect(submit.element).toHaveProperty('disabled', true);
    await submit.trigger('click');
    expect(submitProcessStation).not.toHaveBeenCalled();
'''+part[end:]
part=part.replace('shows the server rejection when the previous station is not handed in','blocks submission when the previous station is not handed in');s=s[:a]+part+s[b:];f.write_text(s,encoding='utf-8')
