from pathlib import Path
import sys,re
sys.path.insert(0,'.tools');from slim_helpers import remove,prune,calls,mask
root=Path('backend/src/main/java/com/zhubao/erp');tests=Path('backend/src/test/java/com/zhubao/erp')
p=root/'security/domain/AuthAccountMutation.java';t=p.read_text(encoding='utf-8').replace('AuthAuditEvent audit,\n        )','AuthAuditEvent audit\n    )');p.write_text(t,encoding='utf-8')
p=root/'security/app/AuthUserAccountManagementService.java';t=p.read_text(encoding='utf-8');t=re.sub(r'(newManagementAudit\([^\n]*\)),\n                null\n',r'\1\n',t);t=t.replace('+ reasonSuffix(reason)\n               ;','+ reasonSuffix(reason);');p.write_text(t,encoding='utf-8')
# 准确保留仍有效的测试方法；旧预审批构造／放行的测试随能力退出。
def drop_test(t,name):
 c=mask(t);m=re.search(r'^    void '+re.escape(name)+r'\([^{}]*\)\s*(?:throws [^{]+)?\{',c,re.M)
 if not m:raise ValueError(name)
 a=t.rfind('    @Test',0,m.start());i=m.end();depth=1
 while depth:
  if c[i]=='{':depth+=1
  elif c[i]=='}':depth-=1
  i+=1
 while i<len(t) and t[i]=='\n':i+=1
 return t[:a]+t[i:]
p=tests/'security/app/AuthUserAccountManagementServiceTest.java';t=p.read_text(encoding='utf-8')
for name in ['preApprovalReadinessExposesMissingBlockingApprovalCapabilities','preApprovalReadinessReflectsEnforcedApplicationCodeSwitch','preApprovalDraftEvaluatesMissingEvidenceWithoutWritingApprovalTask','preApprovalDraftRejectsUnknownActionType','preApprovalApplicationPersistsDraftEvaluationAndCreatesHandoffTask','uploadsPreApprovalEvidenceAndCreatesApplicationDocumentPackage','bindsReadyPreApprovalApplicationToAccountCreationAuditAndSummary','enforcingPreApprovalApplicationCodeAllowsReadyApplication','enforcingPreApprovalApplicationCodeRejectsWaitingApprovalTask','enforcingPreApprovalApplicationCodeRejectsApplicationWithoutApprovalTask','rejectsPreApprovalApplicationThatIsNotReadyForAccountAction','completeEvidenceEnablesRealBlockingApprovalAndBindsTheTargetSnapshot','approvedDisableCannotBeUsedToUnlockEnableOrExecuteTwice']:t=drop_test(t,name)
# 历史证据读取仍保留。
p.write_text(t,encoding='utf-8')
p=tests/'security/web/AuthControllerAccountManagementTest.java';t=p.read_text(encoding='utf-8')
for name in re.findall(r'^    void (\w+)\(',t,re.M):
 if any(x in name.lower() for x in ['preapprovalreadiness','preapprovaldraft','preapprovalapplication','preapprovalevidence']) and name!='accountListRequiresManagementPermission':t=drop_test(t,name)
p.write_text(t,encoding='utf-8')
for p in tests.rglob('*.java'):
 t=p.read_text(encoding='utf-8')
 if 'new AuthUserAccountManagementService(' in t:
  def args(x):
   if len(x)<=6:return x[:5]
   y=x[:5]+[x[6],x[7] if len(x)>7 and x[7] not in ['true','false','enforcePreApprovalForAccountActions'] else 'null',x[8] if len(x)>8 and x[8] not in ['true','false','enforcePreApprovalForAccountActions'] else 'null',x[11] if len(x)>11 else 'null',x[12] if len(x)>12 else 'null']
   return y
  p.write_text(calls(t,'AuthUserAccountManagementService',args),encoding='utf-8')
# 提取仍有效的账号事务测试，移除旧申请单条件消费的状态机用例。
p=tests/'security/app/AuthAccountActionContractTest.java';t=p.read_text(encoding='utf-8');c=mask(t)
keep=['缺省账号保存和删除在内存及Jdbc中原子提交授权和审计','内存和Jdbc并发移除管理员仍保留至少一人','removeAdmin','directHarness','probe','audit','enabledAccount','createSchema'];blocks=[]
for name in keep:
 m=re.search(r'^    (?:private |public |static |final )*[^\n;{}]*\b'+re.escape(name)+r'\([^{};]*\)\s*(?:throws [^{]+)?\{',c,re.M)
 if not m:raise ValueError(name)
 a=m.start();before=t[:a].rstrip();a=before.rfind('    @Test') if before.endswith('@Test') else a;i=m.end();depth=1
 while depth:
  if c[i]=='{':depth+=1
  elif c[i]=='}':depth-=1
  i+=1
 blocks.append(t[a:i])
a=t.index('/**');t=t[:a]+'''/** 内存与 H2 验证账号、客户授权、审计原子性以及最后管理员并发保护。 */
class AuthAccountActionContractTest {

'''+ '\n\n'.join(blocks)+'''
    private record DirectHarness(AuthUserAccountRepository accounts, AuthAuditRepository audits,
                                 CustomerAuthorizationRepository customers, AuthAccountActionRepository actions,
                                 AtomicReference<String> failure) { }
}
'''
t=t.replace('AuthAccountMutation.save(proposed, audit("target", "save-rollback"), null)','AuthAccountMutation.save(proposed, audit("target", "save-rollback"))')
t=t.replace('new InMemoryAuthAccountActionRepository(accounts, audits, applications, customers, probe(failure))','new InMemoryAuthAccountActionRepository(accounts, audits, customers, probe(failure))').replace('new JdbcAuthAccountActionRepository(dataSource, accounts, audits, applications, customers, probe(failure))','new JdbcAuthAccountActionRepository(dataSource, accounts, audits, customers, probe(failure))');t=re.sub(r'            @Override\n            public void beforeApplicationWrite\(\) \{[\s\S]*?\n            \}\n','',t);p.write_text(prune(t),encoding='utf-8')
# 清理退出功能的专属类型与任务工厂测试。
p=tests/'approval/app/ApprovalServiceTest.java';t=p.read_text(encoding='utf-8')
for name in ['createsWaitingAccountManagementApprovalSummary','createsWaitingAccountPreApprovalHandoffTask']:t=drop_test(t,name)
t=t.replace('service.findPending()','service.pendingTasks(actor("leader-a", "leader", RoleCode.WORKSHOP_LEADER))')
t=t.replace('ApprovalTask account = service.createAccountManagementApprovalTask(\n                "planner", "创建账号", "系统管理员", "ADMIN", "计划员", "SALES", "SELF", "", true, false);','ApprovalTask account = repository.save(new ApprovalTask("AUTH-HISTORY", "ACCOUNT_MANAGEMENT", "planner", "历史账号申请", ApprovalStatus.WAITING_APPROVAL, "系统管理员", "总经理", "GENERAL_MANAGER", "amber", "WAITING", "", "", false, "2026-07-01", null, null, null, false));')
a=t.index('        ApprovalTask acknowledged =');b=t.index('        assertThat(service.findByCode("LOSS-UNIT-001")',a);t=t[:a]+'''        assertThatThrownBy(() -> service.decide(account.approvalCode(), new ApprovalDecisionCommand("APPROVE", "总经理", "已阅", null), manager))
                .isInstanceOf(PermissionDeniedException.class).hasMessageContaining("历史账号申请只读");
        assertThat(service.pendingTasks(manager)).noneMatch(task -> task.approvalCode().equals(account.approvalCode()));
        assertThat(service.findByCode(account.approvalCode()).status()).isEqualTo(ApprovalStatus.WAITING_APPROVAL);
'''+t[b:];p.write_text(prune(t),encoding='utf-8')
