from pathlib import Path
f=Path('.tools/slim_css.cjs');s=f.read_text(encoding='utf-8')
s=s.replace("const plans = [];",'''function masked(selector) {
  return selector.replace(/\\[[^\\]]*\\]|"(?:\\\\.|[^"\\\\])*"|'(?:\\\\.|[^'\\\\])*'|\\/\\*[\\s\\S]*?\\*\\//g, match => ' '.repeat(match.length));
}
function prune(selector, dead) {
  const hasDead = text => [...dead].some(name => new RegExp('\\\\.'+escaped(name)+'(?![\\\\w-])').test(masked(text)));
  const scan = masked(selector);
  const functions = /:([a-zA-Z-]+)\\(/g;
  let result = '', cursor = 0, match;
  while ((match = functions.exec(scan))) {
    const before = selector.slice(cursor, match.index);
    if (hasDead(before)) return null;
    let end = functions.lastIndex, depth = 1;
    while (end < scan.length && depth) { if (scan[end] === '(') depth++; else if (scan[end] === ')') depth--; end++; }
    if (depth) throw new Error('选择器括号不完整：'+selector);
    const body = selector.slice(functions.lastIndex, end - 1);
    if (['is', 'where'].includes(match[1])) {
      const branches = postcss.list.comma(body).map(part => prune(part, dead)).filter(Boolean);
      if (!branches.length) return null;
      result += before + ':' + match[1] + '(' + branches.join(', ') + ')';
    } else {
      if (hasDead(body)) throw new Error('特殊伪类需人工核对：'+selector);
      result += before + selector.slice(match.index, end);
    }
    cursor = end; functions.lastIndex = end;
  }
  const tail = selector.slice(cursor);
  return hasDead(tail) ? null : result + tail;
}
const plans = [];''')
a=s.index('    const keep = parts.filter(selector => {');b=s.index('    if (keep.length === parts.length)',a)
s=s[:a]+'''    const keep = parts.map(selector => {
      const next = prune(selector, dead);
      if (next !== selector) removed.push({ file, selector, retained: next });
      return next;
    }).filter(Boolean);
'''+s[b:]
s=s.replace('    if (keep.length === parts.length) return;', "    if (keep.length === parts.length && keep.every((selector, i) => selector === parts[i])) return;")
s="process.on('uncaughtException', error => { process.stderr.write(error.message+'\\n'); process.exit(1); });\n"+s
f.write_text(s,encoding='utf-8')
