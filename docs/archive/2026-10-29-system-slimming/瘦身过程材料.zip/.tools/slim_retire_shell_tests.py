from pathlib import Path
f=Path('frontend/src/features/m1/BusinessWorkspaces.test.ts');s=f.read_text(encoding='utf-8');a=s.index("  it('renders inbound documents");b=s.index("  it('renders inventory ledger",a);s=s[:a]+s[b:]
for name in ['InboundWorkspace','ProductionWorkspace','QualityWorkspace']:
 s=s.replace(f"import {name} from './{name}.vue';\n",'')
s=s.replace('import { nextTick, ref }','import { ref }')
f.write_text(s,encoding='utf-8')
for name in ['InboundWorkspace.flow.test.ts','ProgressWorkspace.test.ts']:
 Path('frontend/src/features/m1/'+name).unlink()
f=Path('frontend/src/features/production/MachineOutputPanel.vue');s=f.read_text(encoding='utf-8').replace("machineOutputSummaryLoading ? '读取中' : `${machineOutputSummary.totalRecords} 条`", "machineOutputSummaryLoading ? '读取中' : machineOutputSummaryError ? '未读取' : `${machineOutputSummary.totalRecords} 条`")
s=s.replace('<div class="machine-output-summary-grid">','<div v-if="!machineOutputSummaryError" class="machine-output-summary-grid">').replace('{{ machineOutputSummary.unmatchedMachineRecords }}',"{{ machineOutputSummaryLoading ? '读取中' : machineOutputSummary.unmatchedMachineRecords }}").replace('{{ machineOutputSummary.signatureMissingRecords }}',"{{ machineOutputSummaryLoading ? '读取中' : machineOutputSummary.signatureMissingRecords }}")
f.write_text(s,encoding='utf-8')
