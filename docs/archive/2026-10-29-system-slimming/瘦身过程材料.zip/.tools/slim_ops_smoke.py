from pathlib import Path
f=Path('backend/src/test/java/com/zhubao/erp/m2/M2ManagementApiSmokeTest.java');s=f.read_text(encoding='utf-8');a=s.index('    void exposesOperationsCenterApis()');b=s.index('    @Test',a)
s=s[:a]+'''    void exposesOperationsCenterApis() throws Exception {
        ResponseEntity<String> center = restTemplate.getForEntity("/api/operations/center", String.class);
        assertThat(center.getStatusCode().is2xxSuccessful()).isTrue();
        var data = json.readTree(center.getBody()).path("data");
        for (String key : List.of("summary", "services", "runtimeMetrics", "errorSummaries", "recentLogs", "backupStatuses", "alerts", "checklist")) {
            assertThat(data.has(key)).as(key).isTrue();
        }
        assertThat(data.path("recentLogs").isEmpty()).isTrue();
        assertThat(data.path("errorSummaries").isEmpty()).isTrue();
        assertThat(data.path("hardwareNodes").isEmpty()).isTrue();
        assertThat(center.getBody()).contains("未配置", "OPS-CHK-008").doesNotContain("TRACE-OPS-001", "DB-BACKUP-POC", "RESTORE-DRILL-POC");
    }

'''+s[b:];f.write_text(s,encoding='utf-8')
