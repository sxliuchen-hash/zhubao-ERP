from pathlib import Path
f=Path('frontend/src/features/m1/QualityWorkspace.vue');s=f.read_text(encoding='utf-8')
s=s.replace("import OperationInputs from './OperationInputs.vue';", "import LossApplicationPanel from '../quality/LossApplicationPanel.vue';")
s=s.replace("import { createAmountForm } from './operationAmounts';\n",'').replace("import { operationDraft } from './operationDraft';\n",'')
s=s.replace("import type { LossApproval, Tone }", "import type { Tone }")
s=s.replace("import {\n  approveLoss,\n  type LossApprovalResult,\n} from '../../services/businessOperationApi';\n",'')
a=s.index('const { operationValues, resetAmounts }');b=s.index("const selectedQualityCaseCode",a)
s=s[:a]+"const lossLocked = ref(false);\n"+s[b:]
s=s.replace('watch(activeCase, (item) => { resetAmounts(item?.operationContext); });\n','')
a=s.index('async function approveActiveLoss()');b=s.index('function backToList()',a);s=s[:a]+s[b:]
s=s.replace("  selectedQualityCaseCode.value = code;\n  detailOpen.value = true;\n  lossApprovalResult.value = null;\n  lossApprovalError.value = '';", "  if (lossLocked.value) return;\n  selectedQualityCaseCode.value = code;\n  detailOpen.value = true;")
a=s.index('          <p class="operation-feedback">冻结、返工');b=s.index('        </section>',a)
s=s[:a]+'''          <p class="operation-feedback">冻结、返工、复检和放行从本单质检办理。</p>
          <LossApplicationPanel :key="activeCase.workOrder" :application="{ code: '', workOrder: activeCase.workOrder, process: activeCase.process, operationContext: activeCase.operationContext, standard: '', actual: '', evidence: '', action: '待申请', tone: 'amber' }" @locked="lossLocked = $event" @changed="loadQualityWorkspace" />
'''+s[b:]
s=s.replace(', ref, watch }', ', ref }');f.write_text(s,encoding='utf-8')
f=Path('frontend/src/services/businessOperationApi.ts');s=f.read_text(encoding='utf-8').replace("  return apiPost('/api/business/operations/loss-approvals', buildLossApprovalRequest(row, { ...extra, approver: await actor() }));", "  const operator = await actor();\n  return apiPost('/api/business/operations/loss-approvals', buildLossApprovalRequest(row, { ...extra, operator, approver: operator }));");f.write_text(s,encoding='utf-8')
