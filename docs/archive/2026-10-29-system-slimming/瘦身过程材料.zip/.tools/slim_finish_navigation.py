from pathlib import Path
f=Path('frontend/src/App.vue');s=f.read_text(encoding='utf-8').replace("    activeTab.value = nextTabs[0]?.key ?? 'dashboard';", "    activateTab(nextTabs[0]?.key ?? 'dashboard');")
a=s.index("  if (!visibleTabs.value.some((tab) => tab.key === 'mobile')) return;",s.index('function startDockScan()'));b=s.index('\n}',a);s=s[:a]+s[b:];f.write_text(s,encoding='utf-8')
f=Path('frontend/src/App.test.ts');s=f.read_text(encoding='utf-8');a=s.index("  it('opens the permitted field workspace first on a phone'")
s=s[:a]+'''  it('只有手机菜单也直接使用统一订单页，不恢复旧手机工作台', async () => {
    vi.mocked(fetchAuthSession).mockResolvedValueOnce(sessionWithMenus(['mobile']));
    const wrapper = mount(App); await flushPromises();
    await vi.waitFor(() => expect(wrapper.find('[aria-label="订单查询列表"]').exists()).toBe(true), { timeout: 5000 });
    expect(wrapper.get('h1').text()).toBe('订单中心');
    expect(fetchOrderWorkspace).toHaveBeenCalledWith(expect.objectContaining({ view: 'ORDERS' }));
    wrapper.unmount();
  });

'''+s[a:];f.write_text(s,encoding='utf-8')
