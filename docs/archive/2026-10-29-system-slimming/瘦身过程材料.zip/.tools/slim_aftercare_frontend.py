from pathlib import Path
f=Path('frontend/src/services/businessOperationApi.ts');s=f.read_text(encoding='utf-8')
for name in ['CustomerReturnRequest','AfterSalesReviewRequest','LossApprovalRequest']:
 start=s.index('export interface '+name);end=s.index('\n}',start)
 s=s[:end]+'\n  requestId?: string;'+s[end:]
for fld in ['acceptedQuantity: number;','pieceRate: string;','lossDeductionUnitPrice: string;']:
 start=s.index('export interface LossApprovalRequest');end=s.index('\n}',start)
 part=s[start:end].replace(fld,fld.replace(':','?:',1));s=s[:start]+part+s[end:]
s=s.replace("['reason', '退货原因'], ['operator', '操作人']]);","['reason', '退货原因'], ['operator', '操作人'], ['requestId', '请求编号']]);")
s=s.replace("['disposition', '处理结论'], ['inspector', '质检员'], ['finding', '复核说明']]);","['disposition', '处理结论'], ['inspector', '质检员'], ['finding', '复核说明'], ['requestId', '请求编号']]);")
s=s.replace("    acceptedQuantity: undefined as unknown as number, pieceRate: '', lossDeductionUnitPrice: '', ...extra,","    ...extra,")
s=s.replace("    ['reasonableTransferWeight', '合理转移重量'], ['standardLossRatePercent', '标准损耗率'],\n    ['acceptedQuantity', '验收数量'], ['pieceRate', '计件单价'], ['lossDeductionUnitPrice', '损耗扣减单价']]);","    ['reasonableTransferWeight', '合理转移重量'], ['standardLossRatePercent', '标准损耗率'], ['requestId', '请求编号']]);")
f.write_text(s,encoding='utf-8')
f=Path('frontend/src/features/inventory/InventoryAftercarePanel.vue');s=f.read_text(encoding='utf-8')
s=s.replace('  const command: Command = { mode: kind, values, documentCode:',"  values.requestId = `aftercare-${globalThis.crypto?.randomUUID?.() ?? `${Date.now()}-${Math.random().toString(16).slice(2)}`}`;\n  const command: Command = { mode: kind, values, documentCode:")
s=s.replace('''  busy.value = true;
  try {
    if (kind === 'return') {''','''  await send(command);
}
async function send(command: Command) {
  if (busy.value) return;
  busy.value = true;
  error.value = '';
  const { mode: kind, values } = command;
  try {
    if (kind === 'return') {''')
s=s.replace("    if (!disposed) emit('saved');","    if (!disposed) { unknown.value = null; emit('saved'); }")
s=s.replace("    if (!known) unknown.value = command;","    unknown.value = known ? null : command;")
s=s.replace('此处暂停提交，请先核对原单台账，避免重复入库。','原内容已锁定，可用同一请求重试或核对原单台账。<button class="secondary-button" type="button" :disabled="busy" @click="send(unknown)">{{ busy ? \'重试中…\' : \'原请求重试\' }}</button>')
f.write_text(s,encoding='utf-8')
