from pathlib import Path
from slim_helpers import remove, calls
f=Path('backend/src/main/java/com/zhubao/erp/business/app/BusinessOperationService.java');s=f.read_text(encoding='utf-8')
s=s.replace('        assertShipmentLabel(command, command == null ? "" : command.operator());\n        return shipFinishedStock(command, command.operator());','        return shipFinishedStock(command, command.operator());')
s=s.replace('     * 同账号、同请求、同规范化内容回放原结果。未带编号时仍各自提交，不回放。','     * 同账号、同请求、同规范化内容回放原结果；缺少编号直接拒绝。')
s=s.replace('''        if (workUnit == null || businessDocumentRepository == null) {
            return postReturn(command, null);
        }
        String requestId = command.requestId() == null ? "" : command.requestId().trim();
        if (requestId.isEmpty()) {
            requestId = "customer-return-" + command.returnCode().trim();
        }''','''        if (workUnit == null || businessDocumentRepository == null) {
            throw new BusinessException("退货工作单元或单据仓储尚未装配");
        }
        String requestId = command.requestId() == null ? "" : command.requestId().trim();''')
s=s.replace('String actor = command.operator() == null || command.operator().isBlank() ? "return-operator" : command.operator().trim();','String actor = command.operator();')
s=s.replace('returnPayload(command)','commandPayload(command)')
s=remove(s,'returnPayload')
s=s.replace('''    public AfterSalesReviewResult reviewAfterSalesReturn(AfterSalesReviewCommand command) {
        Long ownerCustomerId''','''    public AfterSalesReviewResult reviewAfterSalesReturn(AfterSalesReviewCommand command) {
        if (workUnit == null || businessDocumentRepository == null) {
            throw new BusinessException("售后复核工作单元或单据仓储尚未装配");
        }
        String text = workUnit.execute(new CommandCall(command.requestId(), command.inspector(),
                "AFTER_SALES_REVIEW", "MOTHER_ORDER", command.motherOrderCode(), commandPayload(command)),
                session -> commandPayload(postAfterSalesReview(command, session)));
        return commandResult(text, AfterSalesReviewResult.class);
    }

    private AfterSalesReviewResult postAfterSalesReview(AfterSalesReviewCommand command, WorkSession session) {
        businessDocumentRepository.lockMotherOrder(command.motherOrderCode(), session);
        Long ownerCustomerId''')
s=s.replace('''        StockLedgerEntry entry = stockLedgerService.transfer(new StockTransferCommand(
                "after_sales_review",''','''        StockLedgerEntry entry = postTransfer(new StockTransferCommand(
                "after_sales_review",''')
s=s.replace('''                buildRemark(command)
        ));

        return new AfterSalesReviewResult''','''                buildRemark(command)
        ), session);

        return new AfterSalesReviewResult''')
s=s.replace('''    public LossApprovalResult approveLoss(ApproveLossCommand command) {
        BigDecimal rawLossWeight''','''    public LossApprovalResult approveLoss(ApproveLossCommand command) {
        if (workUnit == null || approvalService == null) {
            throw new BusinessException("损耗申请工作单元或审批仓储尚未装配");
        }
        String text = workUnit.execute(new CommandCall(command.requestId(), command.operator(),
                "LOSS_APPROVAL", "WORK_ORDER", command.workOrderCode(), commandPayload(command)),
                session -> commandPayload(postLoss(command, session)));
        return commandResult(text, LossApprovalResult.class);
    }

    private LossApprovalResult postLoss(ApproveLossCommand command, WorkSession session) {
        BigDecimal rawLossWeight''')
s=s.replace('''        if (approvalService != null) {
            approvalService.createLossApprovalTask(command, result);
        }''','''        approvalService.createLossApprovalTask(result, session);''')
s=s.replace('''    private StockLedgerEntry postTransfer(StockTransferCommand command, WorkSession session) {
        if (session == null) {
            return stockLedgerService.transfer(command);
        }
        return stockLedgerService.transfer(command, session);
    }''','''    private StockLedgerEntry postTransfer(StockTransferCommand command, WorkSession session) {
        if (session == null) throw new IllegalStateException("库存写入必须处于业务工作单元");
        return stockLedgerService.transfer(command, session);
    }

    private static String commandPayload(Object value) {
        try { return RETURN_JSON.writeValueAsString(value); }
        catch (JsonProcessingException ex) { throw new IllegalStateException("无法保存业务请求或结果", ex); }
    }

    private static <T> T commandResult(String value, Class<T> type) {
        try { return RETURN_JSON.readValue(value, type); }
        catch (JsonProcessingException ex) { throw new IllegalStateException("无法读取业务请求结果", ex); }
    }''')
# 内部入库与保存助手只能从已验证的工作单元进入。
s=s.replace('''        StockLedgerEntry entry = session == null
                ? stockLedgerService.transfer(transfer)
                : stockLedgerService.transfer(transfer, session);
        if (session != null) {
            motherOrderSaveProbe.beforeMotherSave();
        }''','''        StockLedgerEntry entry = postTransfer(transfer, session);
        motherOrderSaveProbe.beforeMotherSave();''')
s=s.replace('if (session != null && masterData != null', 'if (masterData != null')
s=s.replace('''        if (session != null && businessDocumentRepository != null) {
            businessDocumentRepository.lockMotherOrder(command.motherOrderCode(), session);
        }''','''        businessDocumentRepository.lockMotherOrder(command.motherOrderCode(), session);''')
s=s.replace('''        if (businessDocumentRepository != null) {
            outboundSaveProbe.beforeOutboundSave();
            saveOutboundOrder(command, entry, session);
        }''','''        outboundSaveProbe.beforeOutboundSave();
        saveOutboundOrder(command, entry, session);''')
s=s.replace('''        boolean exists = session == null
                ? businessDocumentRepository.motherOrderExists(code)
                : businessDocumentRepository.motherOrderExists(code, session);''','''        boolean exists = businessDocumentRepository.motherOrderExists(code, session);''')
s=s.replace('''        boolean exists = session == null
                ? businessDocumentRepository.outboundOrderExists(code)
                : businessDocumentRepository.outboundOrderExists(code, session);''','''        boolean exists = businessDocumentRepository.outboundOrderExists(code, session);''')
for method,rec in [('saveMotherOrder','record'),('saveOutboundOrder','record')]:
 s=s.replace(f'''        if (session == null) {{
            businessDocumentRepository.{method}({rec});
        }} else {{
            businessDocumentRepository.{method}({rec}, session);
        }}''',f'''        businessDocumentRepository.{method}({rec}, session);''')
f.write_text(s,encoding='utf-8')
# 直接构造的测试输入显式提供请求，避免生产代码猜测请求号。
for f in Path('backend/src/test').rglob('*.java'):
 s=f.read_text(encoding='utf-8');old=s
 for klass,n in [('AfterSalesReviewCommand',17),('ApproveLossCommand',18),('CustomerReturnCommand',16)]:
  if 'new '+klass not in s: continue
  s=calls(s,klass,lambda a: a+['"fixture-" + java.util.UUID.randomUUID()'] if len(a)==n else a)
 if f.name=='BusinessOperationServiceTest.java':
  s=s.replace('new BusinessOperationService(new StockLedgerService(repository), null, null, com.zhubao.erp.business.BusinessWorkFixture.unit())','new BusinessOperationService(new StockLedgerService(repository), new ApprovalService(new InMemoryApprovalTaskRepository()), new com.zhubao.erp.business.infra.InMemoryBusinessDocumentRepository(), com.zhubao.erp.business.BusinessWorkFixture.unit())')
 if s!=old:f.write_text(s,encoding='utf-8')
