from pathlib import Path
from slim_helpers import remove,prune
f=Path('backend/src/main/java/com/zhubao/erp/approval/app/ApprovalService.java');s=f.read_text(encoding='utf-8');a=s.index('    public ApprovalTask createLossApprovalTask(ApproveLossCommand');b=s.index('    public ApprovalTask createLossApprovalTask(LossApprovalResult',a);s=s[:a]+s[b:];f.write_text(prune(s),encoding='utf-8')
f=Path('backend/src/test/java/com/zhubao/erp/approval/app/ApprovalServiceTest.java');s=f.read_text(encoding='utf-8').replace('createLossApprovalTask(lossCommand(), lossResult(true))','createLossApprovalTask(lossResult(true), com.zhubao.erp.business.BusinessWorkFixture.session())').replace('createLossApprovalTask(lossCommand(), lossResult(false))','createLossApprovalTask(lossResult(false), com.zhubao.erp.business.BusinessWorkFixture.session())');s=remove(s,'lossCommand');f.write_text(prune(s),encoding='utf-8')
f=Path('backend/src/test/java/com/zhubao/erp/approval/infra/JdbcApprovalTaskRepositoryTest.java');s=f.read_text(encoding='utf-8').replace('service.createLossApprovalTask(lossCommand(), lossResult(true));','repository.save(waitingTask());');s=remove(s,'lossCommand');f.write_text(prune(s),encoding='utf-8')
f=Path('frontend/src/services/businessOperationApi.test.ts');s=f.read_text(encoding='utf-8').replace("returnCode: 'RET-REAL', originalShipmentCode", "requestId: 'return-request-1', returnCode: 'RET-REAL', originalShipmentCode").replace("reviewCode: 'ASR-1', returnCode", "requestId: 'review-request-1', reviewCode: 'ASR-1', returnCode");s=s.replace('损耗试算必须有完整实测和计价输入，审批人取当前会话','损耗申请只要求实物输入和稳定请求，身份取当前会话').replace("standardLossRatePercent: '2', acceptedQuantity: 12, pieceRate: '1.2', lossDeductionUnitPrice: '4', approver: '冒名审批人'", "standardLossRatePercent: '2', requestId: 'loss-request-1', approver: '冒名审批人'").replace("operator: '实际报工人', approver: '当前账号', inputWeight: '30', outputWeight: '29', pieceRate: '1.2'", "operator: '当前账号', approver: '当前账号', inputWeight: '30', outputWeight: '29', requestId: 'loss-request-1'")
f.write_text(s,encoding='utf-8')
f=Path('frontend/src/features/inventory/InventoryAftercarePanel.test.ts');s=f.read_text(encoding='utf-8').replace('非幂等接口结果未知时保留原单并停止重交，只读核对不发第二次写请求','结果未知锁定原内容，原请求重试仍用相同编号和库存维度')
s=s.replace("    expect(wrapper.emitted('saved')).toBeUndefined();", """    expect(wrapper.emitted('saved')).toBeUndefined();
    const first = structuredClone(vi.mocked(returnCustomerShipment).mock.calls[0]);
    expect(first[1]?.requestId).toMatch(/^aftercare-/);
    vi.mocked(returnCustomerShipment).mockRejectedValueOnce(new ApiRequestError('仍未确认', 503, 503));
    await wrapper.findAll('button').find(button => button.text() === '原请求重试')!.trigger('click');
    await flushPromises();
    expect(returnCustomerShipment).toHaveBeenCalledTimes(2);
    expect(vi.mocked(returnCustomerShipment).mock.calls[1]).toEqual(first);""")
f.write_text(s,encoding='utf-8')
