from pathlib import Path
import sys,re
sys.path.insert(0,'.tools');from slim_helpers import calls,mask,prune
base=Path('backend/src/test/java/com/zhubao/erp')
p=base/'business/BusinessWorkFixture.java';p.write_text('''package com.zhubao.erp.business;

/** 老业务场景迁移到正式请求链时使用的显式测试工作单元。 */
public final class BusinessWorkFixture {
    private BusinessWorkFixture() { }
    public static com.zhubao.erp.work.app.BusinessWorkUnit unit() {
        return new com.zhubao.erp.work.app.MemoryBusinessWorkUnit(new com.zhubao.erp.work.infra.InMemoryCommandRequestRepository());
    }
    public static com.zhubao.erp.work.domain.WorkSession session() {
        return new com.zhubao.erp.work.domain.WorkSession() {
            public java.util.Optional<java.sql.Connection> connection() { return java.util.Optional.empty(); }
            public void onRollback(Runnable undo) { }
        };
    }
}
''',encoding='utf-8')
# 只在测试构造时生成一次请求号，重放用例继续使用其显式固定编号。
req='"fixture-" + java.util.UUID.randomUUID()'
unit='com.zhubao.erp.business.BusinessWorkFixture.unit()'
def method_calls(t,name,transform):
 c=mask(t)
 for m in reversed(list(re.finditer(r'\.'+name+r'\s*\(',c))):
  a=m.end();i=a;d=1;last=a;parts=[]
  while d:
   if c[i]=='(':d+=1
   elif c[i]==')':d-=1
   elif c[i]==',' and d==1:parts.append(t[last:i].strip());last=i+1
   i+=1
  parts.append(t[last:i-1].strip());updated=transform(parts)
  if parts!=updated:t=t[:a]+', '.join(updated)+t[i-1:]
 return t
for p in base.rglob('*.java'):
 t=p.read_text(encoding='utf-8');old=t
 for klass,n in [('ConfirmInboundCommand',24),('ShipFinishedStockCommand',23)]:
  if 'new '+klass+'(' in t:t=calls(t,klass,lambda a:a+[req] if len(a)==n else a)
 if 'new QualityCheckCommand(' in t:t=calls(t,'QualityCheckCommand',lambda a:a+[req] if len(a)==3 else a)
 if 'new BusinessOperationService(' in t:t=calls(t,'BusinessOperationService',lambda a:(a+['null']*(3-len(a))+[unit]) if len(a)<4 else a)
 for klass in ['ProcessStationService','QualityRequirementService']:
  if 'new '+klass+'(' in t:t=calls(t,klass,lambda a:a+(['null'] if len(a)==4 else [])+[unit] if len(a) in [4,5] else a)
 for name,n in [('report',3),('reportProduction',2),('openRework',2)]:t=method_calls(t,name,lambda a:a+[req] if len(a)==n else a)
 for name in ['freezeQualityStock','dispatchRework','reportRework','releaseQualityStock']:t=method_calls(t,name,lambda a:a+['com.zhubao.erp.business.BusinessWorkFixture.session()'] if len(a)==1 else a)
 if p.name=='RegisterImportPostingExecutionServiceTest.java':t=method_calls(t,'post',lambda a:a+['new AuthUserAccount("importer", "", "导入员", RoleCode.ADMIN, DataScope.ALL, true, false)'] if len(a)==2 else a)
 if p.name=='DeviceGatewayServiceTest.java':t=method_calls(t,'consume',lambda a:a+['new com.zhubao.erp.security.domain.AuthUserAccount("operator", "", OPERATOR.operator(), OPERATOR.role(), OPERATOR.dataScope(), true, false)'] if len(a)==2 else a)
 if t!=old:p.write_text(t,encoding='utf-8')
# 专属旧报工算法测试退出；现行岗位交工及其事务继续覆盖。
p=base/'business/app/BusinessOperationServiceTest.java';t=p.read_text(encoding='utf-8')
for name in ['reportProductionMovesWipToSemiFinishedForSameWorkOrderDimension','shipFinishedStockMovesFinishedToShippedForSameWorkOrderDimension','shipFinishedStockPersistsStructuredOutboundOrderWhenDocumentRepositoryIsProvided']:
 a=t.rfind('    @Test',0,t.index('void '+name));b=t.find('    @Test',t.index('void '+name));t=t[:a]+t[b:]
t=t.replace('new BusinessOperationService(new StockLedgerService(repository), null, null, '+unit+')','new BusinessOperationService(new StockLedgerService(repository), null, new InMemoryBusinessDocumentRepository(), '+unit+')',1);p.write_text(prune(t),encoding='utf-8')
p=base/'register/app/RegisterImportPostingExecutionServiceTest.java';t=p.read_text(encoding='utf-8').replace('new BusinessOperationService(stockLedgerService, null, null, '+unit+')','new BusinessOperationService(stockLedgerService, null, new com.zhubao.erp.business.infra.InMemoryBusinessDocumentRepository(), '+unit+')');p.write_text(t,encoding='utf-8')
p=base/'business/app/ShippingDeliveryTest.java';t=p.read_text(encoding='utf-8');a=t.index('        assertThatThrownBy(() -> oldPath.operations()');b=t.index('        seed(world, "MD-SHIP-RACE"',a);t=t[:a]+'''        assertThatThrownBy(() -> oldPath.operations().shipFinishedStock(
                order("OUT-SHIP-OLD", "MD-SHIP-OLD", "ZD-SHIP-OLD", 1001L, "10", "20", "YT60000001", null)))
                .isInstanceOf(BusinessException.class).hasMessageContaining("稳定请求编号");
        assertThat(world.finished("MD-SHIP-OLD", "ZD-SHIP-OLD", 1001L)).isEqualByComparingTo("10");
        assertThat(world.shipped("MD-SHIP-OLD", "ZD-SHIP-OLD", 1001L)).isZero();
        assertThat(world.hasOutbound("OUT-SHIP-OLD")).isFalse();
        assertThat(world.shipmentLedgers("MD-SHIP-OLD")).isZero();

'''+t[b:];t=t.replace('只覆盖带请求编号的成品出库，以及未带编号时仍各自提交的旧路径。','覆盖带请求编号的成品出库，并拒绝无编号旧入口。');p.write_text(t,encoding='utf-8')
