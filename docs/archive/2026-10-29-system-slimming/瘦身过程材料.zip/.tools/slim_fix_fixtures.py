from pathlib import Path
p=Path('backend/src/test/java/com/zhubao/erp/business/app')
for name in ['ProcessDeliveryTest.java','QualityDeliveryTest.java']:
 f=p/name;s=f.read_text(encoding='utf-8');needle='                apply(statement, "src/main/resources/db/mysql/V45__m3_mother_order_courier_identity.sql");'
 s=s.replace(needle,needle+'''\n                apply(statement, "src/main/resources/db/mysql/V60__m3_receipt_line_allocation.sql");
                statement.execute("alter table biz_receipt_line add storage_conditions varchar(80)");
                statement.execute("alter table biz_receipt_line add storage_instruction varchar(500)");
                statement.execute("alter table biz_child_line_allocation add storage_conditions varchar(80)");
                statement.execute("alter table biz_child_line_allocation add storage_instruction varchar(500)");''');f.write_text(s,encoding='utf-8')
f=p/'BusinessOperationServiceTest.java';s=f.read_text(encoding='utf-8')
for name in ['returnCustomerShipmentMoves','reviewAfterSalesReturnMoves']:
 a=s.index('    void '+name);b=s.index('    @Test',a)
 part=s[a:b].replace('stockLedgerService, null, null,','stockLedgerService, null, com.zhubao.erp.business.BusinessWorkFixture.documents("MD-20260706-002", 1002L),')
 s=s[:a]+part+s[b:]
f.write_text(s,encoding='utf-8')
