from pathlib import Path
from slim_helpers import calls
import re
f=Path('frontend/src/features/m1/operationDraft.ts');s=f.read_text(encoding='utf-8');a=s.index('/**');s="import type { AfterSalesReviewRequest, CustomerReturnRequest } from '../../services/businessOperationApi';\n\ntype OperationRequest = AfterSalesReviewRequest & CustomerReturnRequest;\n\n"+s[a:];s=s.replace("['quantity', 'acceptedQuantity'].includes(key)","key === 'quantity'");f.write_text(s,encoding='utf-8')
f=Path('frontend/src/services/businessOperationApi.ts');s=f.read_text(encoding='utf-8')
for name in ['ProductionReportRequest','QualityFreezeRequest','QualityReleaseRequest','ReworkDispatchRequest','ReworkReportRequest']:
 s,n=re.subn(r'export interface '+name+r' \{[^}]*\}\n\n','',s);assert n==1,name
start=s.index('export interface LossApprovalRequest');end=s.index('\n}',start);part=s[start:end]
for line in ['  acceptedQuantity?: number;\n','  pieceRate?: string;\n','  lossDeductionUnitPrice?: string;\n']:part=part.replace(line,'')
s=s[:start]+part+s[end:]
for field in ['acceptedQuantity','pieceRate','pieceWage','lossDeduction','trialWage']:s=s.replace('  '+field+': number;','  '+field+': number | null;')
s=s.replace(" ['acceptedQuantity', '验收数量'],",'').replace(" ['pieceRate', '计件单价'],",'').replace(" ['lossDeductionUnitPrice', '损耗扣减单价'],",'')
f.write_text(s,encoding='utf-8')
f=Path('backend/src/main/java/com/zhubao/erp/business/domain/ApproveLossCommand.java');s=f.read_text(encoding='utf-8')
for line in ['        @DecimalMin(value = "0.000") BigDecimal acceptedQuantity,\n','        BigDecimal pieceRate,\n','        BigDecimal lossDeductionUnitPrice,\n']:s=s.replace(line,'')
f.write_text(s,encoding='utf-8')
f=Path('backend/src/main/java/com/zhubao/erp/business/app/BusinessCommandActors.java');s=f.read_text(encoding='utf-8')
for name in ['ReportProductionCommand','FreezeQualityStockCommand','DispatchReworkCommand','ReportReworkCommand','ReleaseQualityStockCommand']:
 s,n=re.subn(r'    public static '+name+r' withActor\([\s\S]*?\n    }\n\n','',s);assert n==1,name
for line in ['                command.acceptedQuantity(),\n','                command.pieceRate(),\n','                command.lossDeductionUnitPrice(),\n']:s=s.replace(line,'')
f.write_text(s,encoding='utf-8')
f=Path('backend/src/main/java/com/zhubao/erp/business/app/BusinessOperationService.java');s=f.read_text(encoding='utf-8').replace('command.acceptedQuantity() == null ? null : command.acceptedQuantity().setScale(3, RoundingMode.HALF_UP)','null');f.write_text(s,encoding='utf-8')
for f in Path('backend/src/test').rglob('*.java'):
 s=f.read_text(encoding='utf-8')
 if 'new ApproveLossCommand(' in s:
  s=calls(s,'ApproveLossCommand',lambda a:a[:13]+a[16:] if len(a)==19 else a);f.write_text(s,encoding='utf-8')
f=Path('docs/16_字段字典与API契约.md');s=f.read_text(encoding='utf-8');a=s.index('### 6.11');b=s.index('### 6.12',a);part=s[a:b]
for line in part.splitlines(keepends=True):
 if any(line.startswith('| `'+field+'`') for field in ['acceptedQuantity','pieceRate','lossDeductionUnitPrice']):part=part.replace(line,'')
s=s[:a]+part+s[b:];s=s.replace('兼容原输入的可空数量，存在时按 3 位小数返回','新申请返回 null，保留历史响应兼容');f.write_text(s,encoding='utf-8')
