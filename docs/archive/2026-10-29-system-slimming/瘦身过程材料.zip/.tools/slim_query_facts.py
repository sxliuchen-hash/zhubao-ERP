from pathlib import Path
p=Path('backend/src/main/java/com/zhubao/erp/business/app')
f=p/'OrderWorkspaceQueryService.java';s=f.read_text(encoding='utf-8');a=s.index('        List<String> steps = processes == null || processes.isEmpty() ? WorkshopProcesses.DEFAULT_ORDER : processes;');b=s.index('        QualityRequirementCheck check = checks.get(code);',a)
s=s[:a]+'''        Set<String> done = submitted.getOrDefault(code, Set.of());
        String current = WorkshopProcesses.current(processes, done);
        String status = done.contains(current) ? WAITING_QUALITY : done.isEmpty() ? WAITING_START : IN_PROCESS;
'''+s[b:];f.write_text(s,encoding='utf-8')
f=p/'ProgressBoardService.java';s=f.read_text(encoding='utf-8');a=s.index('        List<String> steps = processes.isEmpty() ? WorkshopProcesses.DEFAULT_ORDER : processes;');b=s.index('        QualityRequirementCheck check = checks.get(orderCode);',a)
s=s[:a]+'''        Set<String> done = submitted.getOrDefault(orderCode, Set.of());
        String current = WorkshopProcesses.current(processes, done);
        String status = done.contains(current) ? WAITING_QUALITY : done.isEmpty() ? WAITING_START : IN_PROCESS;
'''+s[b:];s=s.replace('''        } else if (allDone) {
            status = WAITING_QUALITY;
''','');f.write_text(s,encoding='utf-8')
f=Path('frontend/src/App.test.ts');s=f.read_text(encoding='utf-8').replace("expect(wrapper.get('h1').text()).toBe('手机作业');", "expect(wrapper.get('h1').text()).toBe('订单中心');").replace("expect(wrapper.get('.mobile-tab[data-mobile-section=\"more\"]').classes()).toContain('active');\n    wrapper.unmount();\n    if (mediaDevices)","expect(wrapper.get('.mobile-tab[data-mobile-section=\"orders\"]').classes()).toContain('active');\n    wrapper.unmount();\n    if (mediaDevices)");f.write_text(s,encoding='utf-8')
f=Path('frontend/src/features/m1/scanTargetGuard.test.ts');s=f.read_text(encoding='utf-8').replace("    expect(wrapper.text()).toContain('贴纸已变化，请重新识别');", "    expect(wrapper.find('[aria-label=\"核对 1 内壁刻字\"]').exists()).toBe(false);\n    expect(lookupProcessStation).toHaveBeenCalledOnce();");f.write_text(s,encoding='utf-8')
