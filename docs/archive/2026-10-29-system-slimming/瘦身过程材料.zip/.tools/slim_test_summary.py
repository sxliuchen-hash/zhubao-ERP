from pathlib import Path
import subprocess,xml.etree.ElementTree as E,json
files=subprocess.check_output(['git','-c','core.quotepath=false','diff','--name-only'],text=True,encoding='utf-8').splitlines()+subprocess.check_output(['git','-c','core.quotepath=false','ls-files','--others','--exclude-standard'],text=True,encoding='utf-8').splitlines()
rows=[]
for p in files:
 if not p.startswith('backend/src/test/java/') or not p.endswith('Test.java') or not Path(p).exists():continue
 name=p.removeprefix('backend/src/test/java/').removesuffix('.java').replace('/','.')
 report=Path('backend/target/surefire-reports')/('TEST-'+name+'.xml')
 if not report.exists():rows.append({'name':name,'missing':True});continue
 a=E.parse(report).getroot().attrib
 rows.append({'name':name,**{k:a.get(k) for k in ['tests','failures','errors','skipped','timestamp']}})
print(json.dumps({'total':sum(int(r.get('tests') or 0) for r in rows), 'failures':[r for r in rows if r.get('failures') not in [None,'0'] or r.get('errors') not in [None,'0']], 'missing':[r for r in rows if r.get('missing')], 'count':len(rows)},ensure_ascii=False))
Path('.tools/slim-current-results.json').write_text(json.dumps(rows,ensure_ascii=False,indent=2),encoding='utf-8')
