from pathlib import Path
import re,sys
sys.path.insert(0,'.tools');from slim_helpers import remove,prune,calls
root=Path('backend/src/main/java/com/zhubao/erp');tests=Path('backend/src/test/java/com/zhubao/erp')
p=root/'security/app/AuthUserAccountManagementService.java';t=p.read_text(encoding='utf-8')
for name in ['preApprovalReadiness','preApprovalDraft','uploadPreApprovalEvidence','submitPreApprovalApplication']:t=remove(t,name,'public')
for name in ['evidenceMatches','applicationStatus','applicationNextAction','requirePreApprovalApplication','preApprovalEvidenceDocumentCode','preApprovalEvidencePackage','createPreApprovalTask','withPreApprovalTask','validatePreApprovalApplication','validateTargetSnapshot','validateStatusSnapshot','requireApprovedPreApprovalTask','preApprovalActionForUpsert','preApprovalApplicationSuffix','requirePreApprovalApplicationRepository','preApprovalMissingCapabilities','parsePreApprovalAction','buildPreApprovalDraftSummary','nextPreApprovalApplicationCode']:
 t=remove(t,name)
t=re.sub(r'        AuthAccountPreApprovalApplication preApprovalApplication = validatePreApprovalApplication\([\s\S]*?\);\n','',t);t=re.sub(r'^        validate(?:Target|Status)Snapshot\([^\n]*\n','',t,flags=re.M);t=t.replace('                + preApprovalApplicationSuffix(preApprovalApplication)\n','').replace(' + preApprovalApplicationSuffix(preApprovalApplication)','');t=t.replace('                + preApprovalApplicationSuffix(preApprovalApplication);',';');t=t.replace('                preApprovalApplication\n','                null\n');
# 构造器保留基础测试入口与单一完整装配。
a=t.index('    public AuthUserAccountManagementService(');b=t.index('    public List<AccountAccessProfile>',a)
t=t[:a]+'''    public AuthUserAccountManagementService(AuthUserAccountRepository accounts, PasswordHasher hasher, PasswordPolicy policy,
                                            PasswordExpiryPolicy expiry, AuthAuditRepository audits) {
        this(accounts, hasher, policy, expiry, audits, null, null, null, null, null);
    }

    @Autowired
    public AuthUserAccountManagementService(AuthUserAccountRepository accountRepository, PasswordHasher passwordHasher,
            PasswordPolicy passwordPolicy, PasswordExpiryPolicy passwordExpiryPolicy, AuthAuditRepository authAuditRepository,
            AuthAccountPreApprovalApplicationRepository preApprovalApplicationRepository, AuthSessionService authSessionService,
            DocumentManagementRepository documentManagementRepository, CustomerAuthorizationService customerAuthorizationService,
            AuthAccountActionRepository actionRepository) {
        this.accountRepository = accountRepository;
        this.passwordHasher = passwordHasher;
        this.passwordPolicy = passwordPolicy;
        this.passwordExpiryPolicy = passwordExpiryPolicy;
        this.authAuditRepository = authAuditRepository;
        this.preApprovalApplicationRepository = preApprovalApplicationRepository;
        this.authSessionService = authSessionService;
        this.documentManagementRepository = documentManagementRepository;
        this.customerAuthorizationService = customerAuthorizationService;
        this.actionRepository = actionRepository != null ? actionRepository : new InMemoryAuthAccountActionRepository(
                accountRepository, authAuditRepository, customerAuthorizationService == null ? null : customerAuthorizationService.repository(), null);
    }

'''+t[b:]
for line in ['    private final ApprovalService approvalService;\n','    private final DocumentManagementService documentManagementService;\n','    private final boolean enforcePreApprovalForAccountActions;\n','    private final AtomicLong applicationSequence = new AtomicLong();\n']:t=t.replace(line,'')
t=re.sub(r'    private static final DateTimeFormatter APPLICATION_CODE_TIME[\s\S]*?;\n','',t);a=t.index('    private enum PreApprovalAction');t=t[:a]+'}\n';t=t.replace('账号已经停用且申请已消费后，只重试会话吊销。不会再次修改账号，也不会再次消费申请。','账号已经停用后，只重试会话吊销，不再次修改账号。').replace('不要再次执行该申请','不要再次修改账号').replace('上传或绑定 ','历史证据缺少：').replace('保留账号前置审批附件并等待审批复核','保留历史账号申请附件');p.write_text(prune(t),encoding='utf-8')
p=root/'security/web/AuthController.java';t=p.read_text(encoding='utf-8')
for name,annotation in [('accountPreApprovalReadiness','@GetMapping("/accounts/pre-approval-readiness")'),('draftAccountPreApproval','@PostMapping("/accounts/pre-approval-drafts")'),('uploadAccountPreApprovalEvidence','@PostMapping(value = "/accounts/pre-approval-evidence/uploads", consumes = MediaType.MULTIPART_FORM_DATA_VALUE)'),('submitAccountPreApprovalApplication','@PostMapping("/accounts/pre-approval-applications")')]:t=remove(t,name,'public').replace('    '+annotation+'\n','')
p.write_text(prune(t),encoding='utf-8')
for f in ['backend/src/main/resources/application.yml','backend/src/main/resources/application-mysql.yml']:
 p=Path(f);t=p.read_text(encoding='utf-8');t=re.sub(r'^      enforce-account-actions:[^\n]*\n','',t,flags=re.M);p.write_text(t,encoding='utf-8')
p=root/'approval/app/ApprovalService.java';t=p.read_text(encoding='utf-8')
for name,access in [('createAccountManagementApprovalTask','public'),('createAccountPreApprovalTask','public'),('findPending','public'),('buildAccountManagementSummary','private'),('buildAccountPreApprovalSummary','private'),('preApprovalSeverity','private'),('nextAccountApprovalCode','private'),('nextAccountPreApprovalCode','private'),('firstOrDefault','private'),('joinList','private')]:t=remove(t,name,access)
t=re.sub(r'^    private (?:static final DateTimeFormatter ACCOUNT_APPROVAL_CODE_TIME|final AtomicLong account(?:Pre)?ApprovalSequence)[^\n]*\n','',t,flags=re.M);p.write_text(prune(t),encoding='utf-8')
p=root/'approval/app/ApprovalAccess.java';t=p.read_text(encoding='utf-8').replace('        if (task.status() != ApprovalStatus.WAITING_APPROVAL || samePerson(actor, task.applicant())) {','        if (ACCOUNT_MANAGEMENT.equals(task.scene()) || ACCOUNT_PRE_APPROVAL.equals(task.scene())) return false;\n        if (task.status() != ApprovalStatus.WAITING_APPROVAL || samePerson(actor, task.applicant())) {').replace('        if (task.status() != ApprovalStatus.WAITING_APPROVAL) {','        if (ACCOUNT_MANAGEMENT.equals(task.scene()) || ACCOUNT_PRE_APPROVAL.equals(task.scene())) {\n            throw new PermissionDeniedException("历史账号申请只读，不能审批该场景；管理员直接管理账号");\n        }\n        if (task.status() != ApprovalStatus.WAITING_APPROVAL) {');p.write_text(t,encoding='utf-8')
# 退出申请消费，账号、授权和审计继续同次提交。
p=root/'security/domain/AuthAccountMutation.java';t=p.read_text(encoding='utf-8');t=t.replace('        AuthAccountPreApprovalApplication application,\n','').replace('        AuthAccountPreApprovalApplication application\n','');t=t.replace('AuthAuditEvent audit, AuthAccountPreApprovalApplication application)','AuthAuditEvent audit)');t=t.replace('this(kind, account, username, enabled, audit, application, null);','this(kind, account, username, enabled, audit, null);');t=t.replace('            AuthAuditEvent audit,\n    )','            AuthAuditEvent audit\n    )');t=t.replace('audit, application','audit').replace('audit, null, List.of()','audit, List.of()');t=t.replace('申请单为空表示本次没有前置申请需要消费。','账号、客户授权和审计同次提交。');p.write_text(prune(t),encoding='utf-8')
p=root/'security/infra/InMemoryAuthAccountActionRepository.java';t=p.read_text(encoding='utf-8');t=t.replace('    private final AuthAccountPreApprovalApplicationRepository applicationRepository;\n','');a=t.index('    public InMemoryAuthAccountActionRepository(');b=t.index('    @Override',a);t=t[:a]+'''    @Autowired
    public InMemoryAuthAccountActionRepository(AuthUserAccountRepository accounts, AuthAuditRepository audits,
                                               CustomerAuthorizationRepository customers) {
        this(accounts, audits, customers, AuthAccountActionProbe.NONE);
    }
    public InMemoryAuthAccountActionRepository(AuthUserAccountRepository accounts, AuthAuditRepository audits,
                                               CustomerAuthorizationRepository customers, AuthAccountActionProbe probe) {
        this.accountRepository = accounts;
        this.auditRepository = audits;
        this.customerRepository = customers;
        this.probe = probe == null ? AuthAccountActionProbe.NONE : probe;
    }

'''+t[b:];t=t.replace('            AuthAccountPreApprovalApplication currentApplication = lockApplication(mutation);\n','');a=t.index('                if (currentApplication != null)');b=t.index('            } catch',a);t=t[:a]+t[b:];t=t.replace(', auditEventId, currentApplication)',', auditEventId)');t=remove(t,'lockApplication');t=t.replace('            String auditEventId,\n            AuthAccountPreApprovalApplication previousApplication','            String auditEventId');t=t.replace('        if (previousApplication != null) {\n            applicationRepository.save(previousApplication);\n        }\n','');t=t.replace('同一锁内检查申请、写账号、写审计并消费申请','同一锁内保护最后管理员、写账号、客户授权和审计');p.write_text(prune(t),encoding='utf-8')
p=root/'security/infra/JdbcAuthAccountActionRepository.java';t=p.read_text(encoding='utf-8');t=t.replace('    private final JdbcAuthAccountPreApprovalApplicationRepository applicationRepository;\n','');a=t.index('    public JdbcAuthAccountActionRepository(');b=t.index('    @Override',a);t=t[:a]+'''    @Autowired
    public JdbcAuthAccountActionRepository(DataSource dataSource, JdbcAuthUserAccountRepository accounts,
            JdbcAuthAuditRepository audits, CustomerAuthorizationRepository customers) {
        this(dataSource, accounts, audits, customers, AuthAccountActionProbe.NONE);
    }
    public JdbcAuthAccountActionRepository(DataSource dataSource, JdbcAuthUserAccountRepository accounts,
            JdbcAuthAuditRepository audits, CustomerAuthorizationRepository customers, AuthAccountActionProbe probe) {
        this.dataSource = dataSource;
        this.accountRepository = accounts;
        this.auditRepository = audits;
        this.probe = probe == null ? AuthAccountActionProbe.NONE : probe;
        if (customers != null && !(customers instanceof JdbcCustomerAuthorizationRepository)) {
            throw new IllegalArgumentException("JDBC 账号动作必须使用 JDBC 客户授权仓储");
        }
        this.customerRepository = (JdbcCustomerAuthorizationRepository) customers;
    }

'''+t[b:];a=t.index('                String applicationCode =');b=t.index('                probe.beforeAccountWrite();',a);t=t[:a]+t[b:];a=t.index('                if (applicationCode != null)');b=t.index('                connection.commit();',a);t=t[:a]+t[b:];t=remove(t,'notExecutable');a=t.index('/**');b=t.index('@Repository',a);t=t[:a]+'''/** 账号、客户授权和审计使用同一连接提交，最后管理员保护在事务内执行。 */
'''+t[b:];p.write_text(prune(t),encoding='utf-8')
