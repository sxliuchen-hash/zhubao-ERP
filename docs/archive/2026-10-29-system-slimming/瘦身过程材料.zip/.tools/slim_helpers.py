from pathlib import Path
import re

def mask(t):
    pattern = r'"""[\s\S]*?"""|"(?:\\.|[^"\\])*"|//[^\n]*|/\*[\s\S]*?\*/'
    return re.sub(pattern, lambda m: re.sub(r"[^\n]", " ", m[0]), t)

def remove(t, name, access="private"):
    c = mask(t)
    m = re.search(r"^    " + access + r"[^\n;{}]*(?:\n[^{};]*)?\b" + re.escape(name) + r"\s*\([^;{}]*\)(?:\s+throws\s+[\w.,\s]+)?\s*\{", c, re.M)
    if not m:
        raise ValueError("未定位方法：" + name)
    end = m.end()
    depth = 1
    while depth:
        if c[end] == "{": depth += 1
        elif c[end] == "}": depth -= 1
        end += 1
    while end < len(t) and t[end] in "\r\n": end += 1
    return t[:m.start()] + t[end:]

def prune(t):
    for m in list(re.finditer(r"^import ([\w.]+);\n", t, re.M)):
        if len(re.findall(r"\b" + m[1].split(".")[-1] + r"\b", t)) == 1:
            t = t.replace(m[0], "")
    return t

def calls(t, klass, transform):
    c = mask(t)
    for m in reversed(list(re.finditer(r"new " + klass + r"\s*\(", c))):
        start = m.end(); i = start; depth = 1; parts = []; last = start
        while depth:
            ch = c[i]
            if ch == "(": depth += 1
            elif ch == ")": depth -= 1
            elif ch == "," and depth == 1: parts.append(t[last:i].strip()); last = i + 1
            i += 1
        parts.append(t[last:i-1].strip())
        t = t[:start] + ", ".join(transform(parts)) + t[i-1:]
    return t
