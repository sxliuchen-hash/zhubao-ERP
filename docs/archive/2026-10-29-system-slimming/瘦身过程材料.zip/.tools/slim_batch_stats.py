from pathlib import Path
import subprocess,json
changed=subprocess.check_output(['git','-c','core.quotepath=false','diff','--name-only'],text=True,encoding='utf-8').splitlines()
untracked=subprocess.check_output(['git','-c','core.quotepath=false','ls-files','--others','--exclude-standard'],text=True,encoding='utf-8').splitlines()
def finance(p):return '/finance/' in p or 'FinanceWorkspace' in p or p.endswith('services/financeApi.ts')
def prod(p):return p.startswith('backend/src/main/') and p.endswith('.java') or p.startswith('frontend/src/') and p.endswith(('.ts','.vue','.css')) and not p.endswith('.test.ts')
stats={'C3':[0,0], 'finance':[0,0]}
for row in subprocess.check_output(['git','-c','core.quotepath=false','diff','--numstat'],text=True,encoding='utf-8').splitlines():
 a,d,p=row.split('\t');
 if prod(p):
  v=stats['finance' if finance(p) else 'C3'];v[0]+=int(a);v[1]+=int(d)
for p in untracked:
 if prod(p):stats['finance' if finance(p) else 'C3'][0]+=len(Path(p).read_text(encoding='utf-8').splitlines())
manifest=[p for p in changed+untracked if not finance(p) and not p.startswith('docs/')]
manifest+=['docs/16_字段字典与API契约.md']
Path('.tools/slim-c3-manifest.json').write_text(json.dumps(manifest,ensure_ascii=False),encoding='utf-8')
print(json.dumps({'production':stats,'C3files':len(manifest)},ensure_ascii=False))
